# approvals-frontend

Vue.JS based front end for camunda showcase for approvals.