<template>
  <div id="app" class="app-wrapper">
      <v-app id="inspire">
        <Navbar/>
        <Sidebar />
        <router-view />
      </v-app>
  </div>
</template>
  </div>
</template>

<script>
import Header from "./components/Header";
import Sidebar from "./components/Sidebar";
import Navbar from "./components/Navbar";
export default {
  name: "app",
  components: {
    Header,
    Navbar,
    Sidebar,
  },
  data: function () {
    return {
      authenticated: false,
      logoPath: require("@/assets/Mercedes-Benz-Logo.png"),
      mercText: require("@/assets/mercedes_benz.png"),
      username: "",
      groupname: "",
    };
  },

  created() {
    this.isAuthenticated();
  },
  mounted() {
    if (localStorage.getItem("okta-token-storage")) {
      this.username = JSON.parse(
        localStorage.getItem("okta-token-storage")
      ).idToken.claims.name;
    }
    if (sessionStorage.getItem("loggedInUserGroup")) {
      this.groupname = sessionStorage.getItem("loggedInUserGroup");
    }
  },
  watch: {
    // Everytime the route changes, check for auth status
    $route: "isAuthenticated",
  },
  methods: {
    async isAuthenticated() {
      this.authenticated = await this.$auth.isAuthenticated();
    },
    login() {
      this.$auth.loginRedirect("/");
    },
    async logout() {
      await this.$auth.logout();
      await this.isAuthenticated();
    },
    getUsername() {
      return {
        username: localStorage.getItem("okta-token-storage").idToken.claims
          .name,
      };
    },
  },
};
</script>

<style>
.app-wrapper {
  height: 100vh;
}

.header {
  font: 20px osb, Helvetica, sans-serif;
  text-transform: capitalize;
  color: white;
}

/* .search-icon{
    margin-right: 20px;
  }

  .search-feild >>> input{
    align-self: stretch;
  } */

/* #navbar{
    padding-right: 20px;
    padding-left: 20px;
    position: sticky;
  } */

.user-profile-name {
  font: 13px osl, Helvetica, sans-serif;
}

.mercText {
  margin-top: 7%;
  margin-left: -36px;
}

.logo {
  margin-left: 17px;
}

/* .v-main {
    padding: 0 !important;
  } */

.v-application--wrap {
  background-color: #fff !important;
}

.data-container .container--fluid {
  padding: 0 !important;
  margin-top: 5px;
}
</style>
