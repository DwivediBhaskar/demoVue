

export default {
  oidc: {
    clientId: '0oaczyt7FZtYQmcLE5d5',
    issuer: 'https://dev-8085033.okta.com/oauth2/default',
    redirectUri: 'http://localhost:8080/login/callback',
    scopes: ['openid', 'profile', 'email'],
    pkce: true
  },
  backend: {
    baseUrl: 'http://localhost:9090'
  }
}
