import Vue from 'vue'
import Router from 'vue-router'
import CreateRequest from '@/components/CreateRequest'
import Login from '@/components/Login'
import Requests from '@/components/Requests'
import RequestDetails from '@/components/RequestDetails'

import Auth from '@okta/okta-vue'
import OktaLogin from '@/components/LoginOkta'
import Sample from '@/components/Sample'
import Test from '@/components/Test'
import EquipmentList from '@/components/EquipmentList.vue'
Vue.use(Router)

import config from '@/config'
Vue.use(Auth, config.oidc)

const router = new Router({
  mode: 'history',
  routes: [
    /*{
      path: '/',
      name: 'login',
      component: Login
    },*/
    {
      path: '/',
      component: Sample
    },
    {
      path:"/test",
      component:Test
    },
    {
      path:"/equipmentList",
      component:EquipmentList
    },
    {
      path: '/login/callback',
      component: Auth.handleCallback()
    },
    /*{
      path: '/login',
      name: 'login',
      component: Login
    },*/
    {
      path: '/createRequest',
      name: 'CreateRequest',
      component: CreateRequest
    },
    {
      path: '/requests',
      name: 'Requests',
      component: Requests
    },
    {
      path: '/requestDetails/:proposalId',
      name: 'RequestDetails',
      component: RequestDetails
    }
    // ,
    // {
    //   path: '/sample',
    //   name: 'Sample',
    //   component: Sample
    // }
  ]
})

router.beforeEach(Vue.prototype.$auth.authRedirectGuard())

export default router
