<template>
  <div>
    <v-app-bar
      app
      dense
      fixed
      id="navbar"
      color="#262626"
      dark
      height="60px"
      position="sticky"
    >
      <v-app-bar-nav-icon><v-img max-height="40px" max-width="40px"  :src = "logoPath"></v-img></v-app-bar-nav-icon>

      <v-toolbar-title class="header-title">Mercedes-Benz</v-toolbar-title>

      <v-spacer></v-spacer>
      
      
      <v-menu
        v-if="username"
        left
        bottom
      >
        <template v-slot:activator="{ on, attrs }">
          <v-btn
            icon
            v-bind="attrs"
            v-on="on"
          >
        <v-avatar color="black" size="40px">
          <v-icon dark >
            mdi-account-circle
          </v-icon>
        </v-avatar>
        </v-btn>
        </template>
        <!-- <v-list>
          <v-list-item
            v-for="n in 3"
            :key="n"
            @click="() => {}"
          > -->
            <!-- <v-list-item-title>Option {{ n }}</v-list-item-title>
          </v-list-item>
        </v-list> -->
      </v-menu>
      <span v-if="username" class="user-profile-name"> &nbsp;&nbsp;Welcome, {{username}} <span v-if="groupname">[ {{groupname}} ]</span></span>
      
    </v-app-bar> 
  </div>
</template>

<script>
export default {
    name:"header1",
    data: function () {     
    return { authenticated: false,
    logoPath : require('@/assets/Mercedes-Benz-Logo.png'),
    mercText : require('@/assets/mercedes_benz.png'),
    username:'',
    groupname:''
    };
  },
  mounted(){
    if(localStorage.getItem('okta-token-storage')){
      this.username=JSON.parse(localStorage.getItem('okta-token-storage')).idToken.claims.name;
    }
    if(sessionStorage.getItem('loggedInUserGroup')){
      this.groupname=sessionStorage.getItem('loggedInUserGroup');
    }
  },
}
</script>
<style>
.header-title {  
  font:20px osm, Helvetica, sans-serif;   
  text-transform:capitalize;
  color: white; 
}

header{
  height: 0px;
}

#navbar{
  padding-right: 5px;
  padding-left: 5px;
  position: fixed;
}
  
.user-profile-name{
  font:13px ;
  font-family: osl, Helvetica, sans-serif;
}

.logo {
  margin-left: 17px;
}

.v-application--wrap{
  background-color:#fff !important;
}

.data-container .container--fluid {
  padding: 0 !important;
}

.theme--dark.v-toolbar.v-sheet{
  height: 60px;
}

</style>