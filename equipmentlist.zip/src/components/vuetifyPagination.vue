<template>
  <v-app>
    <v-container fluid>
      <v-row row justify-center class="text-lg-center">
        <v-col xs2 v-for="card in cards" :key="card.title" cols="4">
          <v-card
            :class="[
              card.status === 'Rejected'
                ? 'redcard'
                : card.status === 'Approved'
                ? 'greencard'
                : 'orangecard',
            ]"
          >
            <v-card-text>
              <v-simple-table>
                <tr>
                  <td class="text-left font-weight-bold text--secondary">
                    Request Number:
                  </td>
                  <td class="text-left text--secondary">
                    {{ card.requestId }}
                  </td>
                </tr>
                <tr>
                  <td class="text-left font-weight-bold text--secondary">
                    Workflow Name:
                  </td>
                  <td class="text-left text--secondary">{{ card.name }}</td>
                </tr>
                <tr>
                  <td class="text-left font-weight-bold text--secondary">
                    Created By:
                  </td>
                  <td class="text-left text--secondary">
                    {{ card.requestor }}
                  </td>
                </tr>
                <tr>
                  <td class="text-left font-weight-bold text--secondary">
                    Created Date:
                  </td>
                  <td class="text-left text--secondary">
                    {{ card.requestDateTime }}
                  </td>
                </tr>
                <tr>
                  <td class="text-left font-weight-bold text--secondary">
                    Workflow Status:
                  </td>
                  <td class="text-left text--secondary">{{ card.status }}</td>
                </tr>
              </v-simple-table>
            </v-card-text>
            <v-card-actions>
              <v-btn text color="blue accent-4"> View Details </v-btn>
            </v-card-actions>
          </v-card>
        </v-col>
      </v-row>
      <v-row row class="text-lg-center">
        <v-col>
          <v-pagination
            :length="totalPages"
            v-model="currentPage"
            @input="handlePageChange"
          ></v-pagination>
        </v-col>
      </v-row>
    </v-container>
  </v-app>
</template>

<style  scoped>
</style>

<script>
import axios from "axios";
export default {
  name: "vuetifyPagination",
  data: () => ({
    currentPage: 1,
    totalPages: 0,
    numberOfItems: 9,
    prevPage: null,
    requestBody: null,
    cards: [],
    errors: [],
    responseBody: [],
    headers: null,
  }),
  mounted() {
    this.formRequestBody();
    this.loadMyRequestDetails();
  },

  methods: {
    handlePageChange: function (value) {
      this.currentPage = value;
      this.formRequestBody();
      this.loadMyRequestDetails();
    },
    loadMyRequestDetails: function () {
      console.log("req" + this.requestBody);
      axios
        .post(
          "http://BLRKEC401164D:9090/requests/search",
          this.requestBody,
          this.headers
        )
        .then((response) => {
          this.responseBody = response.data;
          this.processResponseBody();
        })
        .catch((e) => {
          console.error(e);
        });
    },
    formRequestBody: function () {
      this.requestBody = {
        firstResult: this.currentPage - 1,
        maxResults: 8,
        filters: [
          { name: "BusinessCase", operator: "eq", value: "Business Case - 1" },
        ],
        sorting: [
          { sortBy: "BusinessCase", sortOrder: "asc" },
          { sortBy: "instanceId", sortOrder: "desc" },
        ],
      };
      this.headers = { "Content-Type": "application/json" };
    },
    processResponseBody: function () {
      this.cards = this.responseBody.records;
      this.totalPages =
        this.responseBody.totalRecords / this.responseBody.maxResults;
      if (!Number.isInteger(this.totalPages)) {
        this.totalPages = this.totalPages + 1;
        this.totalPages = parseInt(this.totalPages);
      }
    },
  },
};
</script>
<style scoped>
.v-application {
  background-color: black;
}
.redcard {
  border-bottom: 5px solid red !important;
}
.greencard {
  border-bottom: 5px solid green !important;
}
.orangecard {
  border-bottom: 5px solid orange !important;
}
</style>
