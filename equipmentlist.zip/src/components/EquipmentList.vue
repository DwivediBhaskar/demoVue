<template>
  <v-main>
    <v-row>
      <v-col cols="12" class="title-page">
        <label>EQIUPMENT LIST</label>
      </v-col>
    </v-row>
    <v-container class="py-2 px-6" fluid>
      <v-row>
        <v-col cols="12" sm="6" md="2">
          <label for="modelClass">Model Class</label>
          <input
            type="text"
            class="input-F"
            id="modelClass"
            placeholder="Model Class"
            name="model_Class"
            v-model="modelClass"
          />
        </v-col>
        <v-col cols="12" sm="6" md="2">
          <label for="modelYear">Model Year</label>
          <input
            type="text"
            class="input-F"
            id="modelYear"
            placeholder="Model Year"
            name="model_year"
            v-model="modelYear"
          />
        </v-col>
        <v-col cols="12" sm="6" md="2">
          <label for="bodyStyle">Body Style</label>
          <select
            name="body_style"
            class="input-F"
            id="bodyStyle"
            v-model="bodyStyle"
            aria-placeholder="Body Style"
          >
            <option>All</option>
            <option>AMG</option>
            <option>Cabriolet</option>
          </select>
        </v-col>
        <v-col col="12" sm="12" md="12">
          <v-data-table
            :headers="headers"
            :items="items"
            :expanded.sync="expanded"
            item-key="id"
            :search="search"
            group-by="type"
            id="mytable"
          >
            <template
              v-slot:[`group.header`]="{ group, headers, toggle, isOpen }"
            >
              <td :colspan="headers.length">
                <v-btn
                  @click="toggle"
                  small
                  icon
                  :ref="group"
                  :data-open="isOpen"
                >
                  <v-icon v-if="isOpen">mdi-chevron-up</v-icon>
                  <v-icon v-else>mdi-chevron-down</v-icon>
                </v-btn>
                {{ group }}
              </td>
            </template>
            <template v-slot:expanded-item="{ headers, item }">
              <td :colspan="headers.length">
                <div class="row">
                  <!-- <div class="col-auto">
                        <v-img :src="item.picture.thumbnail" avatar class="mx-4"></v-img>
                    </div> -->
                  <div class="col">
                    <h6>Details</h6>
                    ... {{ item }}
                  </div>
                </div>
              </td>
            </template>
          </v-data-table>
        </v-col>
      </v-row>
    </v-container>
  </v-main>
</template>

<script>
export default {
  name: "EquipmentList",
   data() {
    return {
      search: "",
      items: [
        {
          id: 1,
          type: "All US Equipment",
          code: "B01",
          description: "Integrated Starter Generator with 48V",
          dov: "",
          model: "S",
          comment: "",
        },
        {
          id: 2,
          type: "All US Equipment",
          code: "B05",
          description: "Chrome Plated Handle",
          dov: "",
          model: "MBO",
          comment: "",
        },
        {
          id: 3,
          type: "All US Equipment",
          code: "B51",
          description: "Factory Code - tirefit",
          dov: "",
          model: "S",
          comment: "",
        },
        {
          id: 4,
          type: "All US Equipment",
          code: "B65",
          description: "Champagne Flutes",
          dov: "",
          model: "MBO",
          comment: "",
        },
        {
          id: 5,
          type: "US Stand -Alone Options",
          code: "B05",
          description: "Chrome Plated Handle",
          dov: "",
          model: "MBO",
          comment: "",
        },
        {
          id: 6,
          type: "US Stand -Alone Options",
          code: "B52",
          description: "Factory Code - tirefit",
          dov: "",
          model: "S",
          comment: "",
        },
        {
          id: 7,
          type: "US Stand -Alone Options",
          code: "C21",
          description: "Integrated Starter Generator with 48V",
          dov: "",
          model: "S",
          comment: "",
        },
      ],
      expanded: [],
      togglers: {},
      headers: [
        { text: "Deleate", align: "left", filterable: false, value: "id" },
        { text: "Code", value: "code" },
        { text: "Description", value: "description" },
        { text: "Dov", value: "dov" },
        { text: "S500V4", value: "model" },
        { text: "Product Management Comment", value: "comment" },
      ],
    };
  },
  mounted() {
    // axios.get('https://randomuser.me/api?results=20')
    //     .then(response => {
    //       this.items = response.data.results.map((item) => {
    //           return {
    //             first: item.name.first,
    //             last: item.name.last,
    //             id: item.id.value,
    //             age:item.dob.age,
    //             gender:item.gender,
    //             country: item.location.country,
    //             city: item.location.city,
    //           }
    //       })
    //  })

    setTimeout(() => {
      // wait and then close all groups
      //this.closeAll()
    }, 300);
  },
  methods: {
    toggleAll() {
      Object.keys(this.$refs).forEach((k) => {
        //console.log(this.$refs[k])
        this.$refs[k].$el.click();
      });
    },
    closeAll() {
      Object.keys(this.$refs).forEach((k) => {
        console.log(this.$refs[k]);
        if (this.$refs[k] && this.$refs[k].$attrs["data-open"]) {
          this.$refs[k].$el.click();
        }
      });
    },
    openAll() {
      Object.keys(this.$refs).forEach((k) => {
        if (this.$refs[k] && !this.$refs[k].$attrs["data-open"]) {
          this.$refs[k].$el.click();
        }
      });
    },
  },
};
</script>
<style scoped>
.title-page {
  background-color: #777;
  padding-left: 30px;
  color: white;
  font-size: 20px;
  font-weight: 400;
}
.input-F {
  margin: 2px 10px 0px 2px;
  box-shadow: #ccc;
  border-radius: 4px;
  height: 40px;
  border: 1px solid #a9a9a9 !important;
  text-align: center;
  width: 100%;
}
label {
  width: 100%;
}
div.v-data-table__wrapper > table > thead > tr > th {
  color: black !important;
  background-color: #a9a9a9 !important;
  text-align: center !important;
}
#mytable table thead tr th:nth-child(1) {
  background-color: green;
}
</style> 