<template>
<v-app>
 <v-main>
 <v-container ma-0 pa-0 fill-height>
    <v-layout row class="text-xs-center">
      <v-flex xs3 >
      <!-- <v-card height="500px"></v-card> -->
      </v-flex> 
      <v-flex xs5 class="grey lighten-4">
        <v-container style="position: relative;top: 13%;" class="text-xs-center">
          <v-card flat>
            <v-card-title primary-title>
              <h4>Login</h4>
            </v-card-title>
            <v-form  v-model="isValid"  @submit.prevent="onSubmit">
            
            <v-text-field required name="Username" v-model="userId" label="Username" :rules="[v => !!v || 'Username is required']"></v-text-field>
            <v-text-field required name="Password" label="Password" type="password" :rules="[v => !!v || 'Password is required']"></v-text-field>
            <v-card-actions>
              <v-btn primary large block type="Submit" :disabled="!isValid"  color="primary">Login</v-btn>
            </v-card-actions>
            </v-form>
          </v-card>
        </v-container>
      </v-flex>
    </v-layout>
  </v-container>
 </v-main>
</v-app>

</template>

<script>
import axios from 'axios'
  export default {
    name: 'Login',
  data: () => ({
    errors: [],
    responseBody: [],
    requestBody:{"":""},
    headers: null,
    groups:[],
    firstName:String,
    userId:"",
    errors:[],
    isValid:true,
      
  
  }),
  
  methods: {
     loadMyRequestDetails: function () {
        const headers = {"USER_ID":this.userId , "Content-Type": "application/json"}

      console.log("req" + (this.headers));
      axios
        .post(
          "http://BLRKEC330126L:9090/login",
          this.requestBody,
          {headers}
        )
        .then((response) => {
          this.responseBody = response.data;
          console.log("RESPONSE"+( this.responseBody))
          this.processResponseBody();
        })
        .catch((e) => {
          console.log("error"+e)
          this.errors.push(e);
        });
    },
    formRequestBody: function () {
     
     
    },
     processResponseBody: function () {
       console.log()
       this.groups= this.responseBody.groups;
       this.firstName= this.responseBody.firstName;
       this.userId=this.responseBody.userId;
       sessionStorage.setItem("loggedInUser",this.userId)
       if(this.groups!=null && this.groups.length>0 && this.groups[0].id!='Requestor' ){
         sessionStorage.setItem("isGroupUser",true)
        sessionStorage.setItem("loggedInUserGroup",this.groups[0].id)
       }else{
         sessionStorage.setItem("isGroupUser",false)
       }

      this.$router.push({name:"Requests"});

     },auth: function (event){
       console.log("auth");
       this.loadMyRequestDetails();
     },
      onSubmit: function() {
         console.log("auth");
       this.loadMyRequestDetails();
      } ,
    resetValues: function() {
      this.username = "";
      this.password = ""; 
    
  }
  }
};
</script>


<style >
.centered-container {
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  height: 100vh;
  }
.title {
    text-align: center;
    margin-bottom: 30px;
    
  }
 .md-button {
      margin: 0;
    }
  
  .loading-overlay {
    z-index: 10;
    top: 0;
    left: 0;
    right: 0;
    position: absolute;
    width: 100%;
    height: 100%;
    background: rgba(255, 255, 255, 0.9);
    display: flex;
    align-items: center;
    justify-content: center;
  
}
  .md-content {
    z-index: 1;
    padding: 40px;
    width: 100%;
    max-width: 400px;
    position: relative;
  }
   .form {
    margin-bottom: 60px;
  }
  .v-main__wrap{
    background-color: #312e2e;
  }
  .flex.xs5{
    max-height:70%;
  }
</style>