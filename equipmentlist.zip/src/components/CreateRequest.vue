<template>
  <v-app>
    <navbar></navbar>
    <div class="page-title">
      <label>Create Request</label>
    </div>
    <div class="content-wrapper">
      <v-container class="back-btn-wrapper">
        <v-btn depressed color="primary" v-on:click="back">
          <v-icon>mdi-keyboard-backspace</v-icon>
          &nbsp; Back
        </v-btn>
      </v-container>
      <v-container fluid>
        <div >
          <v-form v-model="valid" lazy-validation ref="form">
            <div class="form">
              <v-row>
                <v-col
                  cols="12"
                  sm="6"
                  md="3"
                  class="d-flex justify-start underline"
                >
                  <h2>Request Details</h2><v-spacer></v-spacer>
                  <!-- <v-btn  class="import-button" depressed color="success"  type="file">
                        Import Excel&nbsp;<v-icon>mdi-download  </v-icon>
                      </v-btn> -->
                      <!-- <input id="file-upload" class="import-button" type="file" @change="importExcel"> -->
                     
                </v-col>
              </v-row>
              <v-row>
                <v-col cols="12" md="3">
                <h6 class="field-label">Upload Data</h6>
                <v-file-input   
                   v-on:change="importExcel($event)"
                   v-model="csvFile"
                 ></v-file-input>
                 </v-col>
                 <!-- <v-col><v-btn style="margin-top:30px" color="success" :disabled="!populate" >Populate Data</v-btn></v-col> -->
              </v-row>
              <hr style="margin-bottom:10px"/>
              <v-row>
                <v-col cols="12" sm="6" md="2">
                  <h6 class="field-label">Model Year</h6>
                  <v-text-field
                    ref="modelYear"
                    placeholder="ModelYear"
                    v-model="modelYear"
                    outlined
                    :rules="yearRules"
                  ></v-text-field>
                </v-col>
                <v-col cols="12" sm="6" md="2">
                  <h6 class="field-label">Model</h6>
                  <v-text-field
                    ref="model"
                    placeholder="Model"
                    v-model="model"
                    outlined
                    :rules="modelRules"
                  ></v-text-field>
                </v-col>
                <v-col cols="12" sm="6" md="2">
                  <h6 class="field-label">Lookup</h6>
                  <v-text-field
                    ref="lookup"
                    placeholder="Lookup"
                    v-model="lookup"
                    outlined
                    :rules="lookupRules"
                  ></v-text-field>
                </v-col>
                <v-col cols="12" sm="6" md="3">
                  <h6 class="field-label">Location</h6>
                  <v-text-field
                    ref="location"
                    placeholder="Location"
                    v-model="location"
                    :rules="locationRules"
                    outlined
                  ></v-text-field>
                </v-col>
              </v-row>
              <v-row>
                <v-col cols="12" sm="6" md="2">
                  <h6 class="field-label">Base MSRP</h6>
                  <v-text-field
                    ref="baseMSRP"
                    prefix="$"
                    v-model="baseMSRP"
                    outlined
                    type="number"
                  ></v-text-field>
                </v-col>
                <v-col cols="12" sm="6" md="1">
                  <h6 class="field-label">Package</h6>
                  <v-text-field
                    ref="p1Package"
                    prefix="$"
                    v-model="p1Package"
                    outlined
                    type="number"
                  ></v-text-field>
                </v-col>
                <v-col cols="12" sm="6" md="1">
                  <h6 class="field-label">Option 1</h6>
                  <v-text-field
                    ref="option1"
                    prefix="$"
                    v-model="option1"
                    outlined
                    type="number"
                  ></v-text-field>
                </v-col>
                <v-col cols="12" sm="6" md="1">
                  <h6 class="field-label">Option 2</h6>
                  <v-text-field
                    ref="option2"
                    prefix="$"
                    v-model="option2"
                    outlined
                    type="number"
                  ></v-text-field>
                </v-col>
                <v-col cols="12" sm="6" md="1">
                  <h6 class="field-label">Option 3</h6>
                  <v-text-field
                    ref="option3"
                    prefix="$"
                    v-model="option3"
                    outlined
                    type="number"
                  ></v-text-field>
                </v-col>
                <v-col cols="12" sm="6" md="2">
                  <h6 class="field-label">Equipped MSRP</h6>
                  <v-text-field
                    ref="equippedMSRP"
                    prefix="$"
                    v-model="equippedMSRP"
                    outlined
                    type="number"
                  ></v-text-field>
                </v-col>
                <v-col cols="12" sm="6" md="2">
                  <h6 class="field-label">Destination Charge</h6>
                  <v-text-field
                    ref="destinationCharge"
                    prefix="$"
                    v-model="destinationCharge"
                    outlined
                    type="number"
                  ></v-text-field>
                </v-col>
                <v-col cols="12" sm="6" md="2">
                  <h6 class="field-label">Total MSRP</h6>
                  <v-text-field
                    ref="totalMSRP"
                    prefix="$"
                    v-model="totalMSRP"
                    outlined
                    type="number"
                  ></v-text-field>
                </v-col>
              </v-row>
              <v-row>
                <v-col cols="12" sm="6" md="2">
                  <h6 class="field-label">Dealer Contribution</h6>
                  <v-text-field
                    ref="dealerContribution"
                    prefix="$"
                    v-model="dealerContribution"
                    outlined
                    type="number"
                  ></v-text-field>
                </v-col>
                <v-col cols="12" sm="6" md="2">
                  <h6 class="field-label">Customer Down</h6>
                  <v-text-field
                    ref="customerDown"
                    prefix="$"
                    v-model="customerDown"
                    outlined
                    type="number"
                  ></v-text-field>
                </v-col>
                <v-col cols="12" sm="6" md="2">
                  <h6 class="field-label">Federal Tax Credit</h6>
                  <v-text-field
                    ref="federalTaxCredit"
                    prefix="$"
                    v-model="federalTaxCredit"
                    outlined
                    type="number"
                  ></v-text-field>
                </v-col>
                <v-col cols="12" sm="6" md="2">
                  <h6 class="field-label">Capitalized Cost</h6>
                  <v-text-field
                    ref="capitalizedCost"
                    prefix="$"
                    v-model="capitalizedCost"
                    outlined
                    type="number"
                  ></v-text-field>
                </v-col>
              </v-row>
              <v-row>
                <v-col cols="12" sm="6" md="2">
                  <h6 class="field-label">Term</h6>
                  <v-text-field
                    ref="term"
                    placeholder="Term"
                    v-model="term"
                    outlined
                    type="number"
                    :rules="termRules"
                  ></v-text-field>
                </v-col>
                <v-col cols="12" sm="6" md="2">
                  <h6 class="field-label">Mileage Per Year</h6>
                  <v-text-field
                    ref="mileagePerYear"
                    placeholder="Mileage per year"
                    v-model="mileagePerYear"
                    outlined
                    type="number"
                    :rules="mileageRules"
                  ></v-text-field>
                </v-col>
              </v-row>
              <v-row>
                <v-col cols="12" sm="3" md="2">
                  <h6 class="field-label">Base RV</h6>
                  <v-text-field
                    ref="baseRV"
                    v-model="baseRV"
                    outlined
                    suffix="%"
                    type="number"
                    :rules="baseRVRules"
                  ></v-text-field>
                </v-col>
                <v-col cols="12" sm="3" md="2">
                  <h6 class="field-label">RV Enhancement</h6>
                  <v-text-field
                    class="rv"
                    ref="rvEnhancement"
                    suffix="%"
                    v-model="rvEnhancement"
                    outlined
                    size="3"
                    type="number"
                    :rules="rvEnhancementRules"
                  ></v-text-field>
                </v-col>
                <v-col cols="12" sm="3" md="2">
                  <h6 class="field-label">Published RV</h6>
                  <v-text-field
                    class="rv"
                    ref="publishedRV"
                    suffix="%"
                    v-model="publishedRV"
                    outlined
                    type="number"
                    :rules="publishedRules"
                  ></v-text-field>
                </v-col>
              </v-row>
              <v-row>
                <v-col cols="12" md="3">
                  <h6 class="field-label">Attachments</h6>
                <!-- <input type="file" @change="processFile($event)"> -->
                <v-file-input cols="12" sm="6" md="2"  
                   v-on:change="processFile($event)"
                 ></v-file-input>
                 
                </v-col>
              </v-row>
            </div>
            <v-row align="center" justify="space-around">
              <v-spacer></v-spacer>
              <v-col cols="12" sm="4" md="3" class="submit-btn-wrapper">
                <v-btn primary color="success" v-on:click="save" :disabled="!valid"
                  >Submit</v-btn
                >
              </v-col>
            </v-row>
          </v-form>
        </div>
        <!-- <div class="d-flex flex-column mb-6">
        <v-banner> </v-banner>

      </div> -->
      </v-container>
    </div>

    
    <!-- </v-main> -->
    <v-snackbar top v-model="snackbar" :timeout="2000">
      {{ snackBarText }}

      <template v-slot:action="{ attrs }">
        <v-btn
          color="primary"
          snackBarText
          v-bind="attrs"
          @click="snackbar = false"
        >
          Close
        </v-btn>
      </template>
    </v-snackbar>
    <v-progress-circular
      v-if="showLoader"
      indeterminate
      :size="50"
      :width="10"
    ></v-progress-circular>
  </v-app>
</template>

<script>
import axios from "axios";
import config from "../config";
import Header from "./Header.vue";

export default {
  name: "CreateRequest",
  components:{
    'navbar':Header
  },
  data: () => ({
    csvFile:"",
    populate:false,
    valid:false,
    yearRules: [
      v => !!v || 'Year is required'
    ],
    modelRules: [
      v => !!v || 'Model Name is required'
    ],
    lookupRules: [
      v => !!v || 'Lookup is required'
    ],
    locationRules: [
      v => !!v || 'Location is required'
    ],
    baseRVRules:[
      v=> (v && v<=100) || 'Base RV cannot be greater than 100'
    ],
    rvEnhancementRules:[
      v=> (v && v<=100) || 'RV Enhancement cannot be greater than 100'
    ],
    publishedRules:[
      v=> (v && v<=100) || 'Published RV cannot be greater than 100'
    ],
    termRules:[
      v=> !!v || 'Term is Required'
    ],
    mileageRules:[
      v=> !!v || 'Mileage is Required'
    ],

    fileData:"",
    files:[],
    modelYear:"",
    model:"",
    lookup:"",
    location:"",
    baseMSRP:"",
    p1Package:"",
    option1:"",
    option2:"",
    option3:"",
    equippedMSRP:"",
    destinationCharge:"",
    totalMSRP:"",
    dealerContribution:"",
    customerDown:"",
    federalTaxCredit:"",
    capitalizedCost:"",
    term:"",
    mileagePerYear:"",
    baseRV:"",
    rvEnhancement:"",
    publishedRV:"",

    showLoader:false,
    snackBarText: "",
    snackbar: false,
    date: null,
    menu: false,
    modal: false,
    menu2: false,
    textFile:"",
    // name: "",
    // businessCase: "",
    // proposedSolution: "",
    // benefits: "",
    // cost: null,
    rules: {
      required: (value) => !!value || "Required.",
      counter: (value) => value.length <= 20 || "Max 20 characters",
      email: (value) => {
        const pattern = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return pattern.test(value) || "Invalid e-mail.";
      },
    },

    Company: {
      name: "",
      emailId: "",
      phoneNumber: null,
      incorporationDate: null,
    },
    Address: {
      addressLine1: "",
      addressLine2: "",
      city: "",
      state: "",
      zipCode: "",
      country: "",
    },
    items: [
      {
        text: "My Requests",
        disabled: false,
        href: "requests",
      },
      {
        text: "Create Requests",
        disabled: true,
        href: "breadcrumbs_link_1",
      },
    ],
  }),
  methods: {


    processFile(event){
      this.fileData=event;
      console.log(this.fileData);
    },
    importExcel:function(event){
      console.log("importExcel")
      if(event){
        this.csvFile=event;
        this.populate="true";
        this.loggedInUser = sessionStorage.getItem("loggedInUser");
        const accessToken = sessionStorage.getItem("accessToken");
        const headers = {
          USER_ID: this.loggedInUser,
          "Content-Type": "multipart/form-data",
          Authorization: "Bearer " + accessToken,
        };
      
        this.showLoader = true;
        var formData=new FormData();
        // formData.append('request',this.requestBody);
        formData.append('request', new Blob([JSON.stringify(this.requestBody)], { type: 'application/json'}));
        // formData.append('request', JSON.stringify(this.requestBody), { type: 'application/json'});
        formData.append('file',this.csvFile);
        console.log(JSON.stringify(formData));

        axios
        .post(
          config.backend.baseUrl + "/programguide/read",

          formData,
          { headers }
        )
        .then((response) => {
          // this.responseBody = response.data;
          // console.log("Response "+JSON.stringify(this.response.data))

          if (response.status == 200) {
            console.log("Saved Successfully");
            console.log(JSON.stringify(response.data));
            var responseObject=response.data;
            console.log(responseObject.modelYear);
            this.modelYear=responseObject.modelYear;
            this.model=responseObject.model;
            this.lookup=responseObject.lookup;
            this.location=responseObject.location;
            this.baseMSRP=responseObject.baseMSRP;
            this.p1Package=responseObject.p1Package;
            this.option1=responseObject.option1;
            this.option2=responseObject.option2;
            this.option3=responseObject.option3;
            this.totalMSRP=responseObject.totalMSRP;
            this.equippedMSRP=responseObject.equippedMSRP;
            this.destinationCharge=responseObject.destinationCharge;
            this.dealerContribution=responseObject.dealerContribution;
            this.customerDown=responseObject.customerDown;
            this.federalTaxCredit=responseObject.federalTaxCredit;
            this.capitalizedCost=responseObject.capitalizedCost;
            this.term=responseObject.term;
            this.mileagePerYear=responseObject.mileagePerYear;
            this.baseRV=responseObject.baseRV;
            this.rvEnhancement=responseObject.rvEnhancement;
            this.publishedRV=responseObject.publishedRV;
            // this.snackBarText = "Request Created Successfully";
            // this.snackbar = true;
            // setTimeout(this.back, 2000);
            // this.$router.go(-1);
          } else {
            this.snackBarText = "Something Went Wrong";
            this.snackbar = true;
          }

          // this.processResponseBody();
        })
        .catch((e) => {
          this.snackBarText =
            "An unexpected error has occured. Please try again later.";
          this.snackbar = true;
          console.error(e);
        })
        .finally(() => {
          this.showLoader = false;
        });
        }
      
       
    },
    save: function (event) {
      console.log("save");
      if(this.$refs.form.validate()){
         this.formRequestBody();
         this.loadMyRequestDetails();
      }
     
    },

    loadMyRequestDetails: function () {
     console.log("req" + this.requestBody);
      this.loggedInUser = sessionStorage.getItem("loggedInUser");
      const accessToken = sessionStorage.getItem("accessToken");
      const headers = {
        USER_ID: this.loggedInUser,
        "Content-Type": "multipart/form-data",
        Authorization: "Bearer " + accessToken,
      };
      
      this.showLoader = true;
      var formData=new FormData();
      // formData.append('request',this.requestBody);
      formData.append('request', new Blob([JSON.stringify(this.requestBody)], { type: 'application/json'}));
      // formData.append('request', JSON.stringify(this.requestBody), { type: 'application/json'});
      formData.append('file',this.fileData);
      console.log(JSON.stringify(formData));
      axios
        .post(
          config.backend.baseUrl + "/programguide/submit",

          formData,
          { headers }
        )
        .then((response) => {
          // this.responseBody = response.data;
          // console.log("Response "+JSON.stringify(this.response.data))

          if (response.status == 200) {
            console.log("Saved Successfully");
            this.snackBarText = "Request Created Successfully";
            this.snackbar = true;
            setTimeout(this.back, 2000);
            // this.$router.go(-1);
          } else {
            this.snackBarText = "Something Went Wrong";
            this.snackbar = true;
          }

          // this.processResponseBody();
        })
        .catch((e) => {
          this.snackBarText =
            "An unexpected error has occured. Please try again later.";
          this.snackbar = true;
          console.error(e);
        })
        .finally(() => {
          this.showLoader = false;
        });
    },
    formRequestBody: function () {
      
     this.requestBody={
        modelYear:this.modelYear,
        model:this.model,
        lookup:this.lookup,
        location:this.location,
        baseMSRP:this.baseMSRP,
        p1Package:this.p1Package,
        option1:this.option1,
        option2:this.option2,
        option3:this.option3,
        equippedMSRP:this.equippedMSRP,
        destinationCharge:this.destinationCharge,
        totalMSRP:this.totalMSRP,
        dealerContribution:this.dealerContribution,
        customerDown:this.customerDown,
        federalTaxCredit:this.federalTaxCredit,
        capitalizedCost:this.capitalizedCost,
        term:this.term,
        mileagePerYear:this.mileagePerYear,
        baseRV:this.baseRV,
        rvEnhancement:this.rvEnhancement,
        publishedRV:this.publishedRV
      };
      
      this.headers = { "Content-Type": "multipart/form-data" };
    
    },
    back: function (event) {
      this.$router.go(-1);
    },
  },
};
</script>

<style scoped>
.v-container{
  border: solid black 2px;
}

.back-btn-wrapper {
  text-align: right;
  margin-right: -1%;
}

h2{
  font:17px osb, Helvetica, sans-serif;   
  text-transform: uppercase;
  font-weight: bold;
}

.form-div{
  border: solid 1px rgb(156, 154, 154);
  border-radius: 5px;
  padding: 5px 10px 5px 10px;
  margin: 0px 0px 10px 0px;
}
/* 
.form{
  background-color: #999
} */

.submit-btn-wrapper {
  text-align: right;
}

.form{
  border: solid 1px rgb(156, 154, 154);
  border-radius: 5px;
  padding: 5px 10px 5px 10px;
  margin: 0px 0px 10px 0px;
}

.v-text-field--outlined {
  border: none !important;
}

.v-text-field--outlined .rv{
  width: 50px;
}

.import-button{
  position:absolute;
  right: 0;
  margin-right: 10px;
  background-color: #8ec165 !important;
  border-color: #8ec165 !important;
}
</style>
