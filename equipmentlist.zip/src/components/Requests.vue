<template>
  <v-app>
      <navbar></navbar>
    <v-main>
      <v-container fluid >
        <div class="page-title">
          <label v-if="isSalesOpsUser==='SalesOps' ">My Requests</label>
          <label v-else>My Requests</label>
        </div>
        <div class="content-wrapper">
          <div v-if="isSalesOpsUser==='SalesOps'">
            <myRequest></myRequest>
          </div>
          <div v-else>
            <groupRequests></groupRequests>
          </div>
        </div>
      </v-container>
    </v-main>
  </v-app>
</template>


<script>
import LoadMore from './LoadMore.vue'
import GroupRequests from './GroupRequests.vue'
import Header from "./Header.vue"

export default {
  name:'Requests',
  components:{
    'groupRequests':GroupRequests,
    'myRequest':LoadMore,
    'navbar':Header
  },
  
  data: () => ({
    model: null,
    panel: [0, 1],
    disabled: false,
    readonly: false,
    page: 1,
    pageLength: 5,
    numberOfItems: 9,
    prevPage:null,
    isSalesOpsUser:false,
    items: [
      'Group Requests', 'My Requests'
    ],
    cards: [
      {
        reqNumber: "RQ123456",
        workflowName: "ABC",
        createdDate: "12/12/2020",
        createdBy: "PQR",
        status: "Reject"
      },
      {
        reqNumber: "RQ123456",
        workflowName: "ABCD",
        createdDate: "12/12/2020",
        createdBy: "PQRD",
        status: "Approve"
      }, {
        reqNumber: "RQ123456",
        workflowName: "ABCE",
        createdDate: "12/12/2020",
        createdBy: "PQRE",
        status: "Assigned"
      }, {
        reqNumber: "RQ123456",
        workflowName: "ABC",
        createdDate: "12/12/2020",
        createdBy: "PQR",
        status: "Assigned"
      }
      
    ],
    newcards:[
      {
      reqNumber: "RQ123456",
      workflowName: "ABC",
      createdDate: "12/12/2020",
      createdBy: "PQR",
      status: "Assigned"
    },
      {
      reqNumber: "RQ123456",
      workflowName: "ABC",
      createdDate: "12/12/2020",
      createdBy: "PQR",
      status: "Assigned"
    },
      {
      reqNumber: "RQ123456",
      workflowName: "ABC",
      createdDate: "12/12/2020",
      createdBy: "PQR",
      status: "Assigned"
    },
      {
      reqNumber: "RQ123456",
      workflowName: "ABC",
      createdDate: "12/12/2020",
      createdBy: "PQR",
      status: "Assigned"
    },
      {
      reqNumber: "RQ123456",
      workflowName: "ABC",
      createdDate: "12/12/2020",
      createdBy: "PQR",
      status: "Assigned"
    },
      {
      reqNumber: "RQ123456",
      workflowName: "ABC",
      createdDate: "12/12/2020",
      createdBy: "PQR",
      status: "Assigned"
    },
      {
      reqNumber: "RQ123456",
      workflowName: "ABC",
      createdDate: "12/12/2020",
      createdBy: "PQR",
      status: "Assigned"
    },
  ], 
  loggedInUser:"" 
  }),
  mounted() {
    this.isSalesOpsUser=sessionStorage.getItem("loggedInUserGroup");
    this.loggedInUser=sessionStorage.getItem('loggedInUser');
    
  }, 
  methods:{
    next: function(){
      this.cards=this.newcards;
    },
    changeColour: function(status){
      return{
        color: 'red',
        fontSize: '13px'
      }
    }
  }
}
</script>

<style scoped>
</style>