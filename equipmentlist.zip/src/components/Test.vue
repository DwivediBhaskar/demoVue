<template>
  <v-main>
    <v-row>
      <v-col cols="12" class="title-page">
        <label>DASHBOARD</label>
      </v-col>
    </v-row>
    <v-container class="py-8 px-6" fluid>
      <v-row>
    <v-app class="container">
      <h2>Vuetify datatable expand/collapse all groups</h2>
      <v-card color="pink lighten-2">
        <v-card-text>
          <v-btn @click="toggleAll()">Toggle Groups</v-btn>
          <v-btn @click="closeAll()">Close All</v-btn>
          <v-btn @click="openAll()">Open All</v-btn>
        </v-card-text>
    <v-data-table
        :headers="headers"
        :items="items"
        :expanded.sync="expanded"
        item-key="id"
        :search="search"
        group-by="type"
        >
        <template v-slot:[`group.header`]="{ group, headers, toggle, isOpen }">
            <td :colspan="headers.length">
                <v-btn @click="toggle" small icon :ref="group" :data-open="isOpen">
                    <v-icon v-if="isOpen">mdi-chevron-up</v-icon>
                    <v-icon v-else>mdi-chevron-down</v-icon>
                </v-btn>
                {{ group }}
            </td>
        </template>
        <template v-slot:expanded-item="{ headers, item }">
            <td :colspan="headers.length">
                <div class="row">
                    <!-- <div class="col-auto">
                        <v-img :src="item.picture.thumbnail" avatar class="mx-4"></v-img>
                    </div> -->
                    <div class="col">
                        <h6>Details-----------------</h6>
                        ... {{ item }}
                    </div>
                </div>
            </td>
        </template>
      </v-data-table>
      </v-card>
    </v-app>
      </v-row>
   </v-container>
  </v-main>
</template>

<script>
import axios from "axios" ;
export default {
  name: "Test",
  data () {
    return {
      search: '',
      items: [
        {id:1 , type: "All US Equipment" , code:"B01" , description: "Integrated Starter Generator with 48V", dov:"" , model: "S", comment: "" },
        {id:2 , type: "All US Equipment" , code:"B05" , description: "Chrome Plated Handle", dov:"" , model: "MBO", comment: "" },
        {id:3 , type: "All US Equipment" , code:"B51" , description: "Factory Code - tirefit", dov:"" , model: "S", comment: "" },
        {id:4 , type: "All US Equipment" , code:"B65" , description: "Champagne Flutes", dov:"" , model: "MBO", comment: "" },
        {id:5 , type: "US Stand -Alone Options" , code:"B05" , description: "Chrome Plated Handle" , dov: "", model: "MBO", comment:"" },
        {id:6 , type: "US Stand -Alone Options" , code:"B52" , description: "Factory Code - tirefit" , dov:"" , model: "S", comment:"" },
        {id:7 , type: "US Stand -Alone Options" , code:"C21" , description: "Integrated Starter Generator with 48V" , dov: "", model: "S", comment: ""}
],
      expanded: [],
      togglers: {},
      headers: [
        { text: 'Deleate', align: 'left', filterable: false, value: 'id' },
        { text: 'Code', value: 'code' },
        { text: 'Description', value: 'description' },
        { text: 'Dov', value: 'dov' },
        { text: 'S500V4', value: 'model' },
        { text: 'Product Management Comment', value: 'comment' },
      ],
    }
  },
  mounted () {
    // axios.get('https://randomuser.me/api?results=20')
    //     .then(response => {
    //       this.items = response.data.results.map((item) => {
    //           return {
    //             first: item.name.first,
    //             last: item.name.last,
    //             id: item.id.value, 
    //             age:item.dob.age,
    //             gender:item.gender,
    //             country: item.location.country, 
    //             city: item.location.city,
    //           }
    //       })
    //  })
     
     setTimeout(()=>{
         // wait and then close all groups
         //this.closeAll()
     },300)
  },
  methods: {
    toggleAll () {
        Object.keys(this.$refs).forEach(k => {
            //console.log(this.$refs[k])
            this.$refs[k].$el.click()
        })
    },
    closeAll () {
        Object.keys(this.$refs).forEach(k => {
            console.log(this.$refs[k])
            if (this.$refs[k] && this.$refs[k].$attrs['data-open']) {
                this.$refs[k].$el.click()
            }
        })
    },
    openAll () {
        Object.keys(this.$refs).forEach(k => {
            if (this.$refs[k] && !this.$refs[k].$attrs['data-open']) {
                this.$refs[k].$el.click()
            }
        })
    }
  }
};


</script>
