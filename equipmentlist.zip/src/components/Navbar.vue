<template>
  <v-system-bar
    app
    dense
    fixed
    id="navbar"
    color="#262626"
    dark
    height="60px"
    position="sticky"
  >
    <v-app-bar-nav-icon><v-img max-height="40px" max-width="40px"  :src = "logoPath"></v-img></v-app-bar-nav-icon>
    <v-toolbar-title class="header-title">Equipment-List</v-toolbar-title>

    <v-spacer></v-spacer>

    <!-- <v-icon>mdi-square</v-icon> -->
  </v-system-bar>
</template>
    <script>
export default {
  name: "Navbar",
 data: function () {     
    return { authenticated: false,
    logoPath : require('@/assets/Mercedes-Benz-Logo.png'),
    mercText : require('@/assets/mercedes_benz.png'),
    username:'',
    groupname:''
    };
  },
};
</script>
    <style>
.header-title {  
  font:20px osm, Helvetica, sans-serif;   
  text-transform:capitalize;
  color: white; 
  padding:5px;
}

header{
  height: 0px;
}

#navbar{
  padding-right: 5px;
  padding-left: 5px;
  position: fixed;
}
  
.user-profile-name{
  font:13px ;
  font-family: osl, Helvetica, sans-serif;
}

.logo {
  margin-left: 17px;
}

.v-application--wrap{
  background-color:#fff !important;
}

.data-container .container--fluid {
  padding: 0 !important;
}

.theme--dark.v-toolbar.v-sheet{
  height: 60px;
}

</style>
