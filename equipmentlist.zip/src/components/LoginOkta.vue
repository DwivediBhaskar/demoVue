
<template>
  <v-app>
    <navbar></navbar>
    <v-main>
      <!-- <v-container ma-0 pa-0 fill-height> -->
      <div class="content-wrapper">
        <v-container>
          <div
            v-if="!isAuthenticated"
            class="offset-1 col-sm-12 col-md-10 col-12"
          >
            <v-card class="mx-auto login-dialog"  outlined>
              <v-card-title> Please Login </v-card-title>
              <v-card-text>
                <div>
                  On click of the login button you would be reidrected to Okta
                  login after which you can access the application
                </div>
              </v-card-text>
              <v-card-actions>
                <v-btn primary block color="primary" v-on:click="login()"
                  >Login</v-btn
                >
              </v-card-actions>
            </v-card>
          </div>
          <div v-if="isAuthenticated" class="offset-1 col-sm-12 col-md-10 col-12">
            <v-card class="mx-auto redirecting-dialog" outlined>
              <v-card-text>
                <div>Redirecting...</div>
              </v-card-text>
            </v-card>
          </div>
          <!-- <v-layout row class="text-xs-center">
        <v-flex xs3 >
        <v-card height="500px"></v-card> 
        </v-flex> 
        <div v-if="!isAuthenticated">
        <v-flex xs5 class="grey lighten-4">
          <v-container style="position: relative;top: 13%;" class="text-xs-center">
            <v-card flat>
              <v-card-title primary-title>
                <h4> Please Login</h4>
              </v-card-title>
              
              
            
              <v-card-actions>
                <v-btn primary large block   color="primary"  v-on:click="login()">Login</v-btn>
              </v-card-actions>
            
            </v-card>
          </v-container>
        </v-flex>
        </div>
      </v-layout> -->
        </v-container>
      </div>
    </v-main>
  </v-app>

  <!-- <div id="home">
    <h1 class="ui header">PKCE Flow w/ Okta Hosted Login Page</h1>
    <div v-if="!isAuthenticated">
      <p>Please login.</p>
      <button
        id="login-button"
        class="ui primary button"
        role="button"
        v-on:click="login()"
      >
        Login
      </button>
    </div>

    <div v-if="isAuthenticated">
      <p>Welcome back, {{ claims && claims.name }}!</p>
      <p>
        You have successfully authenticated against your Okta org, and have been
        redirected back to this application. You now have an ID token and access
        token in local storage.
      </p>
      <p>Your ID token is {{ idToken }}.</p>
      <p>Your Access token is {{ accessToken }}.</p>
    </div>
  </div> -->
</template>

<script>
import config from "../config";
import axios from "axios";
import Header from "./Header.vue";

export default {
  name: "home",
  components:{
    'navbar':Header
  },
  data: function () {
    return {
      claims: "",
      isAuthenticated: false,
      idToken: "",
      accessToken: "",
      requestBody: { "": "" },
      responseBody: [],
    };
  },
  created() {
    this.setup();
  },
  methods: {
    async setup() {
      this.claims = await this.$auth.getUser();
      this.isAuthenticated = await this.$auth.isAuthenticated();
      this.idToken = await this.$auth.getIdToken();
      this.accessToken = await this.$auth.getAccessToken();

      console.log("this.idToken " + this.idToken);
      console.log("this.accessToken " + this.accessToken);
      console.log("this.isAuthenticated " + this.isAuthenticated);

      if (this.isAuthenticated) {
        this.getUserDetails();
      }
    },
    login() {
      this.$auth.loginRedirect("/");
    },
    getUserDetails: function () {
      const headers = {
        USER_ID: this.claims.preferred_username,
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.accessToken,
      };
      axios
        .post(config.backend.baseUrl + "/login", this.requestBody, { headers })
        .then((response) => {
          this.responseBody = response.data;
          console.log("Login API response " + this.responseBody);
          this.processUserDetailsResponse();
        })
        .catch((e) => {
          console.error(e);
        });
    },
    processUserDetailsResponse: function () {
      const groups = this.responseBody.groups;
      const userId = this.responseBody.userId;
      sessionStorage.setItem("loggedInUser", this.responseBody.userId);
      sessionStorage.setItem("accessToken", this.accessToken);
      if (groups != null && groups.length > 0 && groups[0].id != "Requestor") {
        sessionStorage.setItem("isGroupUser", true);
        sessionStorage.setItem("loggedInUserGroup", groups[0].id);
      } else {
        sessionStorage.setItem("isGroupUser", false);
      }

      this.$router.push({ name: "Requests" });
    },
  },
};
</script>
<style scoped>
/* .v-main__wrap {
  background-color: #353131 !important;
} */

.container--fluid {
  padding: 0 !important;
}

.redirecting-dialog, .login-dialog{
  background: #fff;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.8), 0 1px 2px rgba(0, 0, 0, 0.5);
  border-radius: 2px;
  max-width: 344px;
  font-family: osb, Helvetica, sans-serif;
}

.login-dialog{
  padding-bottom: 10px;
}

.v-card__title {
  justify-content: center;
  font-weight: 700;
}

.v-card__text {
  color: black;
  font-weight: bold;
}

.data-container .container--fluid {
  padding: 0 !important;
}

.theme--dark.v-toolbar.v-sheet{
    height: 60px;
}
</style>

