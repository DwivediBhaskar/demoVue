<template>
  <v-navigation-drawer v-model="drawer" dark app width="200" >
    <!-- <v-sheet color="grey lighten-4" class="pa-4">
      <v-avatar class="mb-4" color="grey darken-1" size="64"></v-avatar>
      <div>dwivedi@mbusa.com</div>
    </v-sheet> -->
    <v-divider></v-divider>
    <v-list dark>
      <template v-for="(item) in items">
        <v-list-item
          v-if="!item.children"
          :key="item.text"
            :to="item.to"

          @click="currentSelection = item.text"
          :class="currentSelection == item.text ? 'grey' : ''"
        >
          <v-list-item-action>
            <v-icon>{{ item.icon }}</v-icon>
          </v-list-item-action>
          <v-list-item-content>
            <v-list-item-title>
              {{ item.text }}
            </v-list-item-title>
          </v-list-item-content>
        </v-list-item>
        <v-list-group
          v-if="item.children"
          :key="item.text"
          v-model="item.model"
          :prepend-icon="item.model ? item.icon : item['icon-alt']"
          append-icon=""
        >
          <template v-slot:activator>
            <v-list-item>
              <v-list-item-content>
                <v-list-item-title>
                  {{ item.text }}
                </v-list-item-title>
              </v-list-item-content>
            </v-list-item>
          </template>
          <v-list-item
            v-for="(child, i) in item.children"
            :key="i"
            @click="
              item.model = false;
              currentSelection = child.text;
            "
            :class="currentSelection == child.text ? 'grey' : ''"
          >
            <v-list-item-action v-if="child.icon">
              <v-icon>{{ child.icon }}</v-icon>
            </v-list-item-action>
            <v-list-item-content>
              <v-list-item-title>
                {{ child.text }}
              </v-list-item-title>
            </v-list-item-content>
          </v-list-item>
        </v-list-group>
      </template>
    </v-list>
  </v-navigation-drawer>
</template>
    <script>
export default {
  name: "Sidebar",
  data: () => ({
    drawer: true,
    items: [
      { icon: "fa fa-dashboard", to:"/", text: "Dashboard" },
      { icon: "fa fa-list", to:"/equipmentList", text: "Equipment List" },
      {
        icon: "mdi-arrow-up",
        "icon-alt": "mdi-arrow_down",
        text: "More",
        model: false,
        children: [
          {  icon: "fa fa-download", text: "Import" },
          { icon: "fa fa-upload", text: "Export" },
          { icon: "fa fa-print", text: "Print" },
          {icon: "fa fa-undo",  text: "Undo changes" },
          { icon: "fa fa-print", text: "Other contacts" },
        ],
      },
    ],
  }),
  created() {
    this.currentSelection = this.items[0].to;
    // retain the current route from this.$route.name or path and set it to current variable
    var current = ''; // set from this.$route
    // var current = 'Print'; // for testing comment above line and uncomment this line
    if (current) {
      var self = this;
      this.items.forEach((item, i) => {
        if (item.text == current) {
          this.currentSelection = current;
        }
        if (item.children && item.children.length) {
          if (item.children.map(x => x.to).includes(current)) {
            self.items[i].model = true;
            this.currentSelection = current;
          }
        }
      })
    }
  }
};
</script>
<style scoped>
.v-list-item--active{
  background-color:#777;
  color: white  !important;
}
</style>
