<template>
  <v-app>
    <!-- <v-main> -->
    <!-- <v-container ma-0 pa-0 fill-height> -->
    <!-- <v-layout wrap>
      <div class="container">
     <v-tabs
          v-model="model"
          centered
          
          slider-color="blue"
        >
          <v-tab
            v-for="item in items"
            :key="item"
          >
            {{ item }}
          </v-tab>
        </v-tabs>
<v-tabs-items v-model="model">
      <v-tab-item > -->
    <!-- Search Panel-->
    <!-- <v-container>
      <v-row>
      <h5 class = "groupRequestHeader">Group Request Details</h5>
      </v-row>
        <v-row>
        <v-col  cols="2"
          sm="2">
         <v-text-field color="white" label="-Search for Request Id-" append-icon="mdi-card-search-outline">
         </v-text-field>
        </v-col>

          <v-col  cols="2"
          sm="2">
         <v-select color="white" label="-Set Status-">
         </v-select>
        </v-col>

        <v-col  cols="2"
          sm="2">
         <v-select color="white" label="-Group Member-">
         </v-select>
        </v-col>

          </v-row>
      </v-container> -->   
    <v-expansion-panels v-model="panel" :disabled="disabled" multiple>
      <v-expansion-panel class="expansion-panel">
        <v-expansion-panel-header class="expansion-panel-header">My Requests</v-expansion-panel-header>
        <v-expansion-panel-content>
          <v-sheet v-if="myRequests.length > 0" class="mx-auto expansion-panel-content-wrapper" elevation="0" max-width="1300">
            <v-slide-group
              v-model="model"
              center-active
              show-arrows
            >
              <v-slide-item
                v-for="card in myRequests"
                :key="n"
                v-slot:default="{ active, toggle }"
              >
                <v-card
                  class="ma-8 req-card"
                  :class="[
                    card.stepName == 'Submit Proposal'
                      ? 'orangecard'
                      : card.stepName == 'IT Review'
                      ? 'bluecard'
                      : card.stepName == 'Second Level Review'
                      ? 'yellowcard'
                      : card.stepName === 'Finance Review'
                      ? 'turquoisecard'
                      : card.stepName === 'Proposal approved'
                      ? 'greencard'
                      : 'redcard',
                  ]"
                  height="200"
                  width="302"
                >
                  <v-card-text>
                    <v-simple-table class="req-card-text">
                      <tr>
                        <td class="text-left font-weight-bold">
                          Request Id:
                        </td>
                        <td class="text-left">
                          {{ card.programGuideId }}
                        </td>
                      </tr>
                      <tr>
                        <td class="text-left font-weight-bold">
                          Model Year:
                        </td>
                        <td class="text-left">
                          {{ card.modelYear }}
                        </td>
                      </tr>
                      <tr>
                        <td class="text-left font-weight-bold">
                          Model:
                        </td>
                        <td class="text-left">
                          {{ card.model }}
                        </td>
                      </tr>
                      <tr>
                        <td class="text-left font-weight-bold">
                          Created Date:
                        </td>
                        <td class="text-left">
                          {{ card.createdDate }}
                        </td>
                      </tr>
                      <tr>
                        <td class="text-left font-weight-bold">
                          Step Name:
                        </td>
                        <td class="text-left">
                          {{ card.stepName }}
                        </td>
                      </tr>
                    </v-simple-table>
                  </v-card-text>
                  <v-card-actions>
                    <v-btn
                      color="outlink"
                      @click="loadRequestDetailsPage(card, true)"
                    >
                      View Details
                      <v-icon
                        right
                        dark
                      >
                        mdi-arrow-right-circle-outline
                      </v-icon>
                    </v-btn>
                  </v-card-actions>
                  <!-- <v-row
              class="fill-height"
              align="center"
              justify="center"
            >
              <div>{{n}}</div>
             
            </v-row> -->
                </v-card>
              </v-slide-item>
            </v-slide-group>
          </v-sheet>
          <div class="no-requests" v-else>No records found</div>
        </v-expansion-panel-content>
      </v-expansion-panel>

      <v-expansion-panel class="expansion-panel">
        <v-expansion-panel-header class="expansion-panel-header">Open Requests</v-expansion-panel-header>
        <v-expansion-panel-content>
          <v-sheet v-if="openRequests.length > 0" class="mx-auto" elevation="0" max-width="1300">
            <v-slide-group
              v-model="model"
              center-active
              show-arrows
            >
              <v-slide-item
                v-for="card in openRequests"
                :key="n"
                v-slot:default="{ active, toggle }"
              >
                <v-card
                  class="ma-8 req-card"
                  :class="[
                    card.stepName == 'Submit Proposal'
                      ? 'orangecard'
                      : card.stepName == 'IT Review'
                      ? 'bluecard'
                      : card.stepName == 'Second Level Review'
                      ? 'yellowcard'
                      : card.stepName === 'Finance Review'
                      ? 'turquoisecard'
                      : card.stepName === 'Proposal approved'
                      ? 'greencard'
                      : 'redcard',
                  ]"
                  height="200"
                  width="302"
                >
                  <v-card-text>
                    <v-simple-table class="req-card-text">
                      <tr>
                        <td class="text-left font-weight-bold">
                          Request Id:
                        </td>
                        <td class="text-left">
                          {{ card.programGuideId }}
                        </td>
                      </tr>
                      <tr>
                        <td class="text-left font-weight-bold">
                          Model Year:
                        </td>
                        <td class="text-left">
                          {{ card.modelYear }}
                        </td>
                      </tr>
                      <tr>
                        <td class="text-left font-weight-bold">
                          Model :
                        </td>
                        <td class="text-left">
                          {{ card.model }}
                        </td>
                      </tr>
                      <tr>
                        <td class="text-left font-weight-bold">
                          Created Date :
                        </td>
                        <td class="text-left">
                          {{ card.createdDate }}
                        </td>
                      </tr>
                      <tr>
                        <td class="text-left font-weight-bold">
                          Current Step :
                        </td>
                        <td class="text-left">
                          {{ card.stepName }}
                        </td>
                      </tr>
                    </v-simple-table>
                  </v-card-text>
                  <v-card-actions>
                    <v-btn
                      color="outlink"
                      @click="loadRequestDetailsPage(card, false)"
                    >
                      View Details
                      <v-icon
                        right
                        dark
                      >
                        mdi-arrow-right-circle-outline
                      </v-icon>
                    </v-btn>
                  </v-card-actions>
                  <!-- <v-row
              class="fill-height"
              align="center"
              justify="center"
            >
              <div>{{n}}</div>
             
            </v-row> -->
                </v-card>
              </v-slide-item>
            </v-slide-group>
          </v-sheet>
          <div class="no-requests" v-else>No records found</div>
        </v-expansion-panel-content>
      </v-expansion-panel>
    </v-expansion-panels>
    <!-- </v-tab-item>
</v-tabs-items>
    </div>
     </v-layout > -->
    <!-- </v-container> -->

    <!-- </v-main> -->
    <v-progress-circular
      v-if="showLoader"
      indeterminate
      :size="50"
      :width="10"
    ></v-progress-circular>
  </v-app>
</template>

<script>
import axios from "axios";
import config from "../config";

export default {
  name: "Sample",
  data: () => ({
    model: null,
    panel: [0, 1],
    items: ["Group Requests", "My Requests"],
    requestBody: null,
    openRequests: [],
    myRequests: [],
    openRequesterrors: [],
    myRequesterrors: [],
    openRequestResponseBody: [],
    myRequestResponseBody: [],
    headers: null,
    numberOfItems: 0,
    loggedInUser: "",
    loggedInUserGroup: "",
    showLoader: false,

  }),
  mounted() {
    this.loggedInUser = sessionStorage.getItem("loggedInUser");
    this.loggedInUserGroup = sessionStorage.getItem("loggedInUserGroup");
    this.formRequestBody();
    this.loadOpenRequestDetails();
    this.loadMyRequestDetails();
  },
  methods: {
    onCardClick(n) {
      this.model = n - 1;
    },
    loadMyRequestDetails: function () {
      const accessToken = sessionStorage.getItem("accessToken");
      
      const headers = {
        USER_ID: this.loggedInUser,
        "Content-Type": "application/json",
        Authorization: "Bearer " + accessToken,
      };
      const url =
        config.backend.baseUrl +"/groups/"+this.loggedInUserGroup+"/programguide/myRequests";
      this.showLoader = true;
      axios
        .post(url, this.requestBody, { headers })
        .then((response) => {
          
          this.myRequestResponseBody = response.data;
          console.log("my requests"+JSON.stringify(response.data));
          
          this.processMyRequestsResponseBody();
        })
        .catch((e) => {
          this.myRequesterrors.push(e);
        })
        .finally(() => {
          this.showLoader = false;
        });
    },
    loadOpenRequestDetails: function () {
      const accessToken = sessionStorage.getItem("accessToken");
      const headers = {
        USER_ID: this.loggedInUser,
        "Content-Type": "application/json",
        Authorization: "Bearer " + accessToken,
      };
      const url =
        config.backend.baseUrl +
        "/groups/" +
        this.loggedInUserGroup +
        "/programguide/open";
      this.showLoader = true;
      axios
        .post(url, this.requestBody, { headers })
        .then((response) => {
          this.openRequestResponseBody = response.data;
          this.processOpenRequestResponseBody();
        })
        .catch((e) => {
          this.openRequesterrors.push(e);
        })
        .finally(() => {
          this.showLoader = false;
        });
    },
    formRequestBody: function () {
      this.requestBody = {
        firstResult: 0,
        maxResults: 100,
      };
    },
    processOpenRequestResponseBody: function () {
      this.openRequests = this.openRequestResponseBody.records;
      console.log(this.openRequests);
      //this.numberOfItems=this.responseBody.maxResults
    },
    processMyRequestsResponseBody: function () {
      this.myRequests = this.myRequestResponseBody.records;
      console.log(this.myRequests);
      // this.numberOfItems=this.responseBody.maxResults
    },
    loadRequestDetailsPage: function (card, showApprove) {
      console.log("req" + this.requestBody);
      sessionStorage.setItem("showApprove", showApprove);
      this.$router.push({
        name: "RequestDetails",
        params: { proposalId: card.programGuideId },
      });
    },
  },
};
</script>

<style>
.v-application--wrap {
  background-color: #ffffff !important;
}

/*  Icon Color of Accordions */
.mdi:before,
.mdi-set {
  color: #fff;
}

.v-slide-group__next,
.v-slide-group__prev {
  min-width: 25px !important;
}

.groupRequestHeader {
  color: white;
  padding-left: 17px;
}

.expansion-panel {
  margin: 1%;
}

.expansion-panel-header {
  padding: 0.5%;
  margin: 0;
  min-height: 33px;
  color: #fff !important;
  background-color: #333 !important;
  border: 2px solid #333;
  font: 12px osl,Helvetica,sans-serif !important;
  text-transform: uppercase;
  border-radius: 4px;
}

.v-expansion-panel--active>.v-expansion-panel-header {
  min-height: 33px;
  border-bottom-left-radius: 0 !important;
  border-bottom-right-radius: 0 !important;
}

.v-expansion-panel-content__wrap, .v-slide-group {
  background-color: #ddd;
  padding: 0 !important;
}

.v-slide-group.v-item-group>.v-slide-group__next,
.v-slide-group.v-item-group>.v-slide-group__prev {
  background-color: #ddd;
}

.v-slide-group.v-item-group>.v-slide-group__next .mdi:before,
.v-slide-group.v-item-group>.v-slide-group__next .mdi-set,
.v-slide-group.v-item-group>.v-slide-group__prev .mdi:before,
.v-slide-group.v-item-group>.v-slide-group__prev .mdi-set {
  color: #333;
  font-size: 40px;
}

.v-slide-group__next--disabled, .v-slide-group__prev--disabled {
  cursor: no-drop !important;
  pointer-events: unset;
}

.no-requests {
  padding: 0.5%;
  text-align: center;
  font: 15px osm,Helvetica,sans-serif;
}
</style>