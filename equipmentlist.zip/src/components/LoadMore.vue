<template>
  <v-app>
    <v-container class="create-btn-wrapper">
      <v-row>
        <v-col class="d-flex justify-end md-10">
          <v-btn depressed color="primary" v-on:click="createReq">
            Create Request
          </v-btn>&nbsp;&nbsp;
          <v-btn color="success" v-on:click="importExcel">Export to Excel &nbsp;<v-icon>mdi-file-export</v-icon></v-btn>
          </v-col>
      </v-row>
    </v-container>
    <v-container fluid class="colorLegendContainer">
      <v-row class="colorLegendRow">
        <v-col class="legend">
          <v-container class="request-status-indicator requestInitatedBlock"></v-container>
        </v-col>
        <v-col class="colorLegend"><h5>Sales ops</h5></v-col>
        <v-col class="legend">
          <v-container class="request-status-indicator itApprovalBlock"></v-container>
        </v-col>
        <v-col class="colorLegend"><h5>FinCont </h5></v-col>
        <v-col class="legend">
          <v-container class="request-status-indicator proposalApprovedBlock"></v-container>
        </v-col>
       <v-col class="colorLegend"><h5>Closed</h5></v-col>
      </v-row>
    </v-container>
    <v-container fluid>
      <v-row row justify-center class="text-lg-center">
        <v-col xs2 v-for="card in cards" :key="card.title" cols="4">
          <v-card
            class="req-card"
            :class="[
              card.stepName == 'Enter Data & Set Baseline'
                ? 'orangecard'
                : card.stepName == 'Edit & Review Sale Data'
                ? 'bluecard'
                : card.stepName == 'End Process'
                ? 'greencard'
                : 'yellowcard',
            ]"
          >
            <v-card-text>
              <v-simple-table class="req-card-text">
                <tr>
                  <td class="text-left font-weight-bold">
                    Guide Id:
                  </td>
                  <td class="text-left">
                    {{ card.programGuideId }}
                  </td>
                </tr>
                <tr>
                  <td class="text-left font-weight-bold">
                    Model Year:
                  </td>
                  <td class="text-left">
                    {{ card.modelYear }}
                  </td>
                </tr>
                <tr>
                  <td class="text-left font-weight-bold">
                    Model:
                  </td>
                  <td class="text-left">
                    {{ card.model }}
                  </td>
                </tr>
                <tr>
                  <td class="text-left font-weight-bold">
                    Created Date:
                  </td>
                  <td class="text-left">{{ card.createdDate }}</td>
                </tr>
                <tr>
                  <td class="text-left font-weight-bold">
                    Current Step:
                  </td>
                  <td class="text-left">{{ card.stepName }}</td>
                </tr>
              </v-simple-table>
            </v-card-text>
            <v-card-actions>
              <v-btn
                color="outlink"
                @click="loadRequestDetailsPage(card)"
              >
                View Details
                <v-icon
                  right
                  dark
                >
                  mdi-arrow-right-circle-outline
                </v-icon>
              </v-btn>
            </v-card-actions>
          </v-card>
        </v-col>
      </v-row>
      <v-row row justify-center class="text-lg-center">
        <v-col cols="4"></v-col>
        <v-col cols="4"></v-col>
        <v-col cols="4" class="footer">
          <div v-if="this.isFinished">
            <label class="footer-label">No more records available.</label>
          </div>
          <div v-else>
            <label class="footer-label">
              Showing {{ recordsShown }} of {{ numberOfItems }} Requests
            </label>
            <v-btn depressed color="primary" @click="handlePageChange">
              {{buttonText}}
            </v-btn>
          </div>
        </v-col>
      </v-row>
    </v-container>
    <v-progress-circular
      v-if="showLoader"
      indeterminate
      :size="50"
      :width="10"
    ></v-progress-circular>
  </v-app>
</template>

<script>
import axios from "axios";
import config from "../config";

export default {
  name: "myRequests",
  data: () => ({
    numberOfItems: 0,
    requestBody: null,
    cards: [],
    newcards: [],
    errors: [],
    responseBody: [],
    headers: null,
    isFinished: false,
    buttonText: "Load More",
    recordsShown: 0,
    loggedInUser: "",
    showLoader: false
  }),
  mounted() {
    this.loggedInUser = sessionStorage.getItem("loggedInUser");
    this.formRequestBody();
    this.loadMyRequestDetails();
  },

  methods: {
    importExcel:function(){
      axios({
                url: 'http://localhost:9090/programguide/myrequests/excel',  //.substring(0, this.scenario.file.lastIndexOf("/"))
                method: "GET",
                headers: {"Accept": "application/vnd.ms-excel",USER_ID: this.loggedInUser},
                responseType: "blob"
            }).then(response => {
                if(response){
                const fileURL = window.URL.createObjectURL(new Blob([response.data]));
                const fileLink = document.createElement("a");
                const filename = 'MyRequests.xlsx'
                fileLink.href = fileURL;
                fileLink.setAttribute("download",filename);
                document.body.appendChild(fileLink);

                fileLink.click();
                }else{
                  this.showLoader=true;
                }
            });
    },
    handlePageChange: function () {
      this.formRequestBody();
      this.loadMyRequestDetails();
    },
    createReq: function (event) {
      console.log("createReq");
      this.$router.push({ path: "createRequest" });
    },
    loadMyRequestDetails: function () {
      const accessToken = sessionStorage.getItem("accessToken");
      const headers = {
        USER_ID: this.loggedInUser,
        "Content-Type": "application/json",
        Authorization: "Bearer " + accessToken,
      };
      console.log("req" + this.requestBody);
      this.showLoader = true;
      axios
        .post(
          config.backend.baseUrl + "/programguide/myrequests",

          this.requestBody,
          { headers }
        )
        .then((response) => {
          this.responseBody = response.data;
          this.cards=this.responseBody.records;
          console.log(JSON.stringify(this.cards));
          this.processResponseBody();
        })
        .catch((e) => {
          console.error(e);
        })
        .finally(() => {
          this.showLoader = false;
        });
    },
    formRequestBody: function () {
      this.requestBody = {
        firstResult: 0,
        maxResults: this.recordsShown + 9,
        filters: [
          { name: "requestor", operator: "eq", value: this.loggedInUser },
        ],
        sorting: [{ sortBy: "startTime", sortOrder: "desc" }],
      };
    },
    processResponseBody: function () {
      // this.cards = this.responseBody.records;
      this.recordsShown = this.responseBody.maxResults;
      this.numberOfItems = this.responseBody.totalRecords;

      if (this.responseBody.totalRecords > this.responseBody.maxResults) {
      } else {
        this.isFinished = true;
      }
    },
    loadRequestDetailsPage: function (card) {
      console.log("req" + this.requestBody);
      this.$router.push({
        name: "RequestDetails",
        params: { proposalId: card.programGuideId },
      });
    },
  },
};
</script>

<style scoped>
.create-btn-wrapper {
  margin: 0;
  max-width: 100%;
  padding: 0;
}

.request-status-indicator {
  border-radius: 100px;
  height: 10px;
  width: 19px;
  box-shadow: 0.8px 0.8px rgba(0, 0, 0, 0.3);
}

.requestInitatedBlock {
  background: #F47621;
}

.itApprovalBlock {
  background: #225EA8;
}

.SecondLevelApprovalBlock {
  background: #f8e300;
}

.ProposalRejectedBlock {
  background: #e03e37;
}

.FinanceApprovalBlock {
  background: #1DB6B6;
}

.proposalApprovedBlock {
  background: #6abe45;
}

.colorLegend {
  width: 103px;
  color: #333;
  display: flex;
  margin-left: 1%;
}

.legend.col {
  flex-basis: 0;
  -webkit-box-flex: 0 !important;
  flex-grow: 0 !important;
  max-width: 0% !important;
  padding: 8px !important;
}

.colorLegendRow {
  padding-left: 20% !important;
  border: 1px solid #dedede;
  border-radius: 4px;
  align-self: center;
}

.colorLegendContainer {
  background: #fff;
  width: 98%;
  align-items: center;
}

.footer {
  text-align: right;
}

.footer-label {
  color: #000;
  font: 14px osl,Helvetica,sans-serif;
  padding-right: 3%;
  font-weight: 700;
}
.req-card{
  align-self: center;
}
</style>
