<template>
    <div class="offset-1 col-sm-12 col-md-10 col-12"> 
      <v-form>
    <v-row>
      
      <v-col   cols="12"
          sm="6"
          md="3"
          class = "d-flex justify-start underline">
          <h2> Request Details</h2>
      </v-col>
    </v-row>
    <v-row>
       <v-col cols="12" sm="6" md="3" >
          <v-text-field
            label="Name"
            placeholder="Name"
            v-model="name"
            filled
            disabled
          ></v-text-field>
        </v-col>
        <v-col cols="12" sm="6" md="3" >
          <v-text-field
            label="Cost"
            placeholder="Cost"
            v-model="cost"
            filled
            disabled
          ></v-text-field>
        </v-col>
     
         </v-row>
         <v-row>
           <v-col
        cols="12"
        sm="4"
      >
        <v-textarea
          filled
          auto-grow
          label="Business Case"
          rows="4"
          row-height="30"
          v-model="businessCase"
          disabled
          
        ></v-textarea>
      </v-col>
       <v-col
        cols="12"
        sm="4"
      >
        <v-textarea
          filled
          auto-grow
          label="Proposed Solution"
          rows="4"
          row-height="30"
          v-model="proposedSolution"
          disabled
        ></v-textarea>
      </v-col>
       <v-col
        cols="12"
        sm="4"
      >
        <v-textarea
          filled
          auto-grow
          label="Benefits"
          rows="4"
          row-height="30"
          v-model="benefits"
          disabled
        ></v-textarea>
      </v-col>
      
    </v-row>
    <v-row>
      
      <v-col   cols="12"
          sm="6"
          md="3"
          class = "d-flex justify-start underline">
          <h2> Company Details</h2>
      </v-col>
    </v-row>
    <v-row>
     <v-col cols="12" sm="4">
        <v-text-field
            label="Company Name"
            placeholder="Company Name"
            filled
            v-model="Company.name"
            disabled
          ></v-text-field>
     </v-col>
      <v-col cols="12" sm="4" >
        <v-text-field
            label="Email"
            placeholder="Email"
            filled
            v-model="Company.emailId"
            disabled
          ></v-text-field>
     </v-col>
      <v-col cols="12" sm="4" >
        <v-text-field
            label="Phone Number"
            placeholder="Phone Number"
            filled
            type="number"
             v-model="Company.phoneNumber"
             disabled
          ></v-text-field>
     </v-col>
    </v-row>
     <v-row>
     <v-col cols="12" sm="4">
          <v-text-field
            v-model="date"
            label="Incorporation Date"
           
            readonly
           disabled
            filled
          ></v-text-field>
       
     </v-col>
      <v-col cols="12" sm="4" >
        <v-text-field
            label="Address Line 1"
            placeholder="Address Line 1"
            filled
            v-model="Address.addressLine1"
            disabled
          ></v-text-field>
     </v-col>
      <v-col cols="12" sm="4" >
        <v-text-field
            label="Address Line 2"
            placeholder="Address Line 2"
            filled
            disabled
             v-model="Address.addressLine2"
          ></v-text-field>
     </v-col>
    </v-row>
    <v-row>
     <v-col cols="12" sm="3">
        <v-text-field
            label="Zip Code"
            placeholder="Zip Code"
            filled
            disabled
             v-model="Address.zipCode"
          ></v-text-field>
     </v-col>
      <v-col cols="12" sm="3" >
        <v-text-field
            label="City"
            placeholder="City"
            filled
            disabled
             v-model="Address.city"
          ></v-text-field>
     </v-col>
      <v-col cols="12" sm="3" >
        <v-text-field
            label="State"
            placeholder="State"
            filled
            disabled
             v-model="Address.state"
          ></v-text-field>
     </v-col>
     <v-col cols="12" sm="3" >
        <v-text-field
            label="Country"
            placeholder="State"
            filled
            disabled
             v-model="Address.country"
          ></v-text-field>
     </v-col>
    </v-row>
    
   </v-form>
    </div>
</template>
<script>
export default {
    name:'ViewRequestDetails',
    props:['responseBody'],
    data: () => ({
        name:'',
      businessCase:'',
      proposedSolution:'',
      benefits:'',
      cost: null,
      Company:
        {
          name:'',
          emailId:'',
          phoneNumber:null,
          incorporationDate:null,
          
        }
      ,Address:{
            addressLine1:'',
            addressLine2:'',
            city:'',
            state:'',
            zipCode:'',
            country:''
          },
    }),
    mounted(){
         this.proposalId = this.$route.params.proposalId;
         console.log(this.proposalId);
          this.loadMyRequestDetails();
    }
}
</script>