<template>
  <v-app>
    <navbar></navbar>
    <div class="page-title">
      <label>Request Detailed View</label>
    </div>
    <div class="content-wrapper">
      <v-container fluid>
        <div>
          <v-slot:extension>
            <v-tabs
	            app
              fixed
              v-model="model"
              dark
              background-color="white"
              color="#4cc0c1"
              show-arrows
            >
            <v-tabs-slider></v-tabs-slider>

              <v-tab v-for="item in items" :key="item">
                {{ item }}
            </v-tab>
            <v-spacer></v-spacer>
            <div class="back-btn-wrapper">
              <v-btn depressed color="primary" v-on:click="back">
                <v-icon>mdi-keyboard-backspace</v-icon>
                Back
              </v-btn>
            </div>
            </v-tabs>
          </v-slot:extension>
          <v-tabs-items v-model="model">
            <v-tab-item >
              <v-row>
                <v-col cols="12" >
                  <v-stepper alt-labels v-model="stepper">
                    <v-stepper-header>
                      <template v-for="(step, index) in steps">
                        <v-stepper-step
                          v-if="step.current == true"
                          :complete="step.current"
                          :editable="step.current"
                          :step="index + 1"
                          >{{ step.steps }}</v-stepper-step
                        >
                        <v-stepper-step
                          color="green"
                          v-else
                          :complete="step.completed"
                          :editable="step.current"
                          :step="index + 1"
                          >{{ step.steps }}</v-stepper-step
                        >
                        <v-divider v-if="index < steps.length - 1" />
                      </template>
                    </v-stepper-header>
                  </v-stepper>
                </v-col>
              </v-row>
               <v-row row justify-center class="text-lg-center">
                <v-col xs2 cols="6">
                  <v-card class="request-card">
                    <v-card-text class = "paddingDetailCard">
                      <v-simple-table>
                        <tr>
                          <td class="text-left font-weight-bold ">
                            Request Id:
                          </td>
                          <td class="text-left ">
                            {{responseBody.programGuideId}}
                          </td>
                        </tr>
                        <tr>
                          <td class="text-left font-weight-bold ">
                            Model Year:
                          </td>
                          <td class="text-left">
                            {{responseBody.modelYear}}
                          </td>
                        </tr>
                        <tr>
                          <td class="text-left font-weight-bold ">
                            Model:
                          </td>
                          <td class="text-left">
                            {{responseBody.model}}
                          </td>
                        </tr>
                        <tr>
                          <td class="text-left font-weight-bold ">
                            Lookup:
                          </td>
                          <td class="text-left ">
                            {{responseBody.lookup}}
                          </td>
                        </tr>
                        <tr>
                          <td class="text-left font-weight-bold ">
                            Location:
                          </td>
                          <td class="text-left ">
                            {{responseBody.location}}
                          </td>
                        </tr>
                        <tr>
                          <td class="text-left font-weight-bold ">
                            Created Date Date:
                          </td>
                          <td class="text-left ">
                            {{responseBody.startDate}}
                          </td>
                        </tr>
                        <tr>
                          <td class="text-left font-weight-bold ">
                            Base MSRP:
                          </td>
                          <td class="text-left ">
                            ${{responseBody.baseMSRP}}
                          </td>
                        </tr>
                        <tr>
                          <td class="text-left font-weight-bold ">
                            Total MSRP:
                          </td>
                          <td class="text-left ">
                            ${{responseBody.totalMSRP}}
                          </td>
                        </tr>
                        <tr>
                          <td class="text-left font-weight-bold ">
                            Term:
                          </td>
                          <td class="text-left ">
                            {{responseBody.term}}
                          </td>
                        </tr>
                        <tr>
                          <td class="text-left font-weight-bold ">
                            Mileage:
                          </td>
                          <td class="text-left ">
                            {{responseBody.mileagePerYear}}
                          </td>
                        </tr>
                        <tr>
                          <td class="text-left font-weight-bold ">
                            Assigned To:
                          </td>
                          <td class="text-left ">
                            {{responseBody.assignedTo}}
                          </td>
                        </tr>
                        <tr>
                          <td class="text-left font-weight-bold ">
                            Step Name:
                          </td>
                          <td class="text-left">
                            {{responseBody.stepName}}
                          </td>
                        </tr>
                        <tr v-if="requestDetails.stepName=='End Process'">
                          <td class="text-left font-weight-bold ">
                            Final Report :
                          </td>
                          <td class="text-left ">
                            <a v-on:click="downloadWorkflow(requestDetails.finalReportName)">{{requestDetails.finalReportName}}</a>
                          </td>
                        </tr>
                      </v-simple-table>
                    </v-card-text>
                  </v-card>
                </v-col>
                <v-col xs2 cols="6" class="">
                  <v-card class="request-card scroll">
                    <v-card-text>
                     <v-timeline
                        align-top
                        dense
                        v-for="(h, index) in history"
                        :key="index"
                      >
                        <v-timeline-item color="#87c2ce" small>
                          <v-row row justify-center class="text-lg-left">
                            <v-col cols="12" md="5">
                              <div>
                                <strong>{{ h.endTime }} </strong>
                              </div>
                              </v-col>
                              <v-col cols="12" md="5">
                              <div class="text-left">                                
                                <strong>{{ h.activityName }}</strong><br/>
                                <div><span style="">{{h.userId}}</span><pre class="comment"><span v-if="h.comment"></span>{{h.comment}}</pre></div>
                              </div>
                              <!-- <div class="caption" v-if="h.comment !== null">
                                {{ h.userId }}<span v-if="h.comment">:{{ h.comment }}</span>
                              </div>
                              <div class="caption" v-else>{{ h.userId }}</div> -->
                            </v-col>
                          </v-row>
                        </v-timeline-item>
                       
                      </v-timeline>
                    </v-card-text>
                  </v-card>
                </v-col>
              </v-row>
              <v-row v-if="(showApprove == 'true') || (requestDetails.assignedTo==loggedInUser && loggedInUserGroup=='SalesOps')">
                <v-row class="comment-div">
                <v-icon>mdi-message reply</v-icon>&nbsp;&nbsp;
                <v-text-field label="Comment" v-model="comment"></v-text-field>
                </v-row>
              </v-row>
              <v-row>
                <div class="submit-button" >
              <v-btn depressed style="margin-bottom:10px" color="success" v-on:click="submit" v-if="requestDetails.assignedTo==loggedInUser && loggedInUserGroup=='SalesOps'">
                Send for Review
              </v-btn>
              <v-btn depressed style="margin-bottom:10px" color="success" @click="claimProposal" v-if="showApprove == 'false'">
                      Claim
                    </v-btn>
               <v-btn depressed style="margin-bottom:10px" color="success" @click="accept" v-if="showApprove == 'true'">
                      Accept
                </v-btn>
                <v-btn depressed style="margin-bottom:10px" color="error" @click="sendBack" v-if="showApprove == 'true'">
                      Send Back to Sales Ops
                </v-btn>
                </div>
              </v-row>
            </v-tab-item>
            <v-tab-item>

              <div >
          <v-form >
            <div class="form">
              <v-row>
                <v-col
                  cols="12"
                  sm="6"
                  md="3"
                  class="d-flex justify-start underline"
                >
                  <h2>Request Details</h2>
                  <v-spacer></v-spacer>
                  <v-btn v-if="!editable && requestDetails.assignedTo!=''" class="edit-button" depressed color="primary" @click="makeEditable">
                        <v-icon>mdi-pencil</v-icon>
                        Edit
                      </v-btn>
                </v-col>
              </v-row>
              <v-row>
                <v-col cols="12" sm="6" md="2">
                  <h6 class="field-label">Model Year</h6>
                  <v-text-field
                    ref="modelYear"
                    v-model="requestDetails.modelYear"
                    outlined
                    filled
                    readonly
                  ></v-text-field>
                </v-col>
                <v-col cols="12" sm="6" md="2">
                  <h6 class="field-label">Model</h6>
                  <v-text-field
                    ref="model"
                    placeholder="Model"
                    v-model="requestDetails.model"
                    outlined
                    filled
                    readonly
                  ></v-text-field>
                </v-col>
                <v-col cols="12" sm="6" md="2">
                  <h6 class="field-label">Lookup</h6>
                  <v-text-field
                    ref="lookup"
                    placeholder="Lookup"
                    v-model="requestDetails.lookup"
                    outlined
                    filled
                    readonly
                  ></v-text-field>
                </v-col>
                <v-col cols="12" sm="6" md="3">
                  <h6 class="field-label">Location</h6>
                  <v-text-field
                    ref="location"
                    placeholder="Location"
                    v-model="requestDetails.location"
                    outlined
                    filled
                    readonly
                  ></v-text-field>
                </v-col>
              </v-row>
              <v-row>
                <v-col cols="12" sm="6" md="2">
                  <h6 class="field-label">Base MSRP</h6>
                  <v-text-field
                    ref="baseMSRP"
                    prefix="$"
                    v-model="requestDetails.baseMSRP"
                    outlined
                    filled
                    readonly
                  ></v-text-field>
                </v-col>
                <v-col cols="12" sm="6" md="1">
                  <h6 class="field-label">Package</h6>
                  <v-text-field
                    ref="p1Package"
                    prefix="$"
                    v-model="requestDetails.p1Package"
                    outlined
                    filled
                    readonly
                  ></v-text-field>
                </v-col>
                <v-col cols="12" sm="6" md="1">
                  <h6 class="field-label">Option 1</h6>
                  <v-text-field
                    ref="option1"
                    prefix="$"
                    v-model="requestDetails.option1"
                    outlined
                    filled
                    readonly
                  ></v-text-field>
                </v-col>
                <v-col cols="12" sm="6" md="1">
                  <h6 class="field-label">Option 2</h6>
                  <v-text-field
                    ref="option2"
                    prefix="$"
                    v-model="requestDetails.option2"
                    outlined
                    filled
                    readonly
                  ></v-text-field>
                </v-col>
                <v-col cols="12" sm="6" md="1">
                  <h6 class="field-label">Option 3</h6>
                  <v-text-field
                    ref="option3"
                    prefix="$"
                    v-model="requestDetails.option3"
                    outlined
                    filled
                    readonly
                  ></v-text-field>
                </v-col>
                <v-col cols="12" sm="6" md="2">
                  <h6 class="field-label">Equipped MSRP</h6>
                  <v-text-field
                    ref="equippedMSRP"
                    prefix="$"
                    v-model="requestDetails.equippedMSRP"
                    outlined
                    filled
                    readonly
                  ></v-text-field>
                </v-col>
                <v-col cols="12" sm="6" md="2">
                  <h6 class="field-label">Destination Charge</h6>
                  <v-text-field
                    ref="destinationCharge"
                    prefix="$"
                    v-model="requestDetails.destinationCharge"
                    outlined
                    filled
                    readonly
                  ></v-text-field>
                </v-col>
                <v-col cols="12" sm="6" md="2">
                  <h6 class="field-label">Total MSRP</h6>
                  <v-text-field
                    ref="totalMSRP"
                    prefix="$"
                    v-model="requestDetails.totalMSRP"
                    outlined
                    filled
                    readonly
                  ></v-text-field>
                </v-col>
              </v-row>
              <v-row>
                <v-col cols="12" sm="6" md="2">
                  <h6 class="field-label">Dealer Contribution</h6>
                  <v-text-field
                    ref="dealerContribution"
                    prefix="$"
                    v-model="requestDetails.dealerContribution"
                    outlined
                    filled
                    readonly
                  ></v-text-field>
                </v-col>
                <v-col cols="12" sm="6" md="2">
                  <h6 class="field-label">Customer Down</h6>
                  <v-text-field
                    ref="customerDown"
                    prefix="$"
                    v-model="requestDetails.customerDown"
                    outlined
                    filled
                    readonly
                  ></v-text-field>
                </v-col>
                <v-col cols="12" sm="6" md="2">
                  <h6 class="field-label">Federal Tax Credit</h6>
                  <v-text-field
                    ref="federalTaxCredit"
                    prefix="$"
                    v-model="requestDetails.federalTaxCredit"
                    outlined
                    filled
                    readonly
                  ></v-text-field>
                </v-col>
                <v-col cols="12" sm="6" md="2">
                  <h6 class="field-label">Capitalized Cost</h6>
                  <v-text-field
                    ref="capitalizedCost"
                    prefix="$"
                    v-model="requestDetails.capitalizedCost"
                    outlined
                    filled
                    readonly
                  ></v-text-field>
                </v-col>
              </v-row>
              <v-row>
                <v-col cols="12" sm="6" md="2">
                  <h6 class="field-label">Term</h6>
                  <v-text-field
                    ref="term"
                    placeholder="Term"
                    v-model="requestDetails.term"
                    outlined
                    :filled="!editable"
                    :readonly="!editable"
                  ></v-text-field>
                </v-col>
                <v-col cols="12" sm="6" md="2">
                  <h6 class="field-label">Mileage Per Year</h6>
                  <v-text-field
                    ref="mileage"
                    placeholder="Mileage per year"
                    v-model="requestDetails.mileagePerYear"
                    outlined
                    :filled="!editable"
                    :readonly="!editable"
                  ></v-text-field>
                </v-col>
              </v-row>
              <v-row class="rv">
                <v-col cols="12" sm="3" md="2">
                  <h6 class="field-label">Base RV</h6>
                  <v-text-field
                    ref="baseRV"
                    v-model="requestDetails.baseRV"
                    outlined
                    suffix="%"
                    :filled="!editable"
                    :readonly="!editable"
                  ></v-text-field>
                </v-col>
                <v-col cols="12" sm="3" md="2">
                  <h6 class="field-label">RV Enhancement</h6>
                  <v-text-field
                    class="rv"
                    ref="rvEnhancement"
                    suffix="%"
                    v-model="requestDetails.rvEnhancement"
                    outlined
                    size="3"
                    :filled="!editable"
                    :readonly="!editable"
                  ></v-text-field>
                </v-col>
                <v-col cols="12" sm="3" md="2">
                  <h6 class="field-label">Published RV</h6>
                  <v-text-field
                    class="rv"
                    ref="publishedRV"
                    suffix="%"
                    v-model="requestDetails.publishedRV"
                    outlined
                    :filled="!editable"
                    :readonly="!editable"
                  ></v-text-field>
                </v-col>
              </v-row>
              <v-row >
                <v-col cols="12" md="3" v-if="editable">
                <!-- <input type="file" @change="processFile($event)"> -->
                <v-file-input cols="12" sm="6" md="2" v-model="fileData"
                  label="Attach File " v-on:change="processFile($event)"
                 ></v-file-input>
                 
                </v-col>
                <v-col v-if="requestDetails.attachmentName" style="margin-left:5px; margin-top:22px" >  
                <a v-on:click="downloadFile(requestDetails.attachmentName)"><v-icon>mdi-download</v-icon>&nbsp;&nbsp;{{requestDetails.attachmentName}}</a><br/>
                </v-col>
              </v-row> 
              <!-- <v-row v-if="editable" style="font-size:12px;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;***You can upload only one file at a time.</v-row> -->
              <!-- <v-row v-if="!editable" style="margin-left:5px">
                <a v-on:click="downloadFile(requestDetails.attachmentName)"><v-icon>mdi-download</v-icon>&nbsp;&nbsp;{{requestDetails.attachmentName}}</a><br/>
              </v-row> -->
              <v-row>
                <v-col class="save-btn-wrapper"
                 v-if="editable==true">
                  <v-btn primary color="success" v-on:click="updateRequest"
                    >Update</v-btn>
                    <v-btn primary color="error" v-on:click="close"
                    >Cancel</v-btn>
                </v-col>
              </v-row>
            </div>
          </v-form>
          <!-- <v-row justify="center" >
            <v-dialog
              v-model="dialog"
              persistent
              width="500px" 
            >
            <v-card>
              <v-row>
              <v-row >
              <div class="dialog-text">Are you sure you want to replace <strong>{{this.requestDetails.attachmentName}}</strong> with <span v-if="fileData"><strong>{{this.fileData.name}} ?</strong></span></div>
                </v-row>
                  <v-row class="dialog-button">
                    <v-col><v-btn color="success" @click="dialog=false">Yes&nbsp;&nbsp;&nbsp;<v-icon>mdi-check</v-icon></v-btn>
                    <v-btn color="error" @click="cancelReplace">No &nbsp;&nbsp;&nbsp;<span style="font-size:20px;">X</span></v-btn></v-col>
                  </v-row>
                  </v-row>
                  </v-card>
            </v-dialog> -->
    <!-- </v-row> -->
        </div>
            </v-tab-item>
          </v-tabs-items>
          
        </div>
      </v-container>
    </div>
    <v-snackbar top v-model="snackbar">
      {{ snackBarText }}
      <template v-slot:action="{ attrs }">
        <v-btn
          color="primary"
          snackBarText
          v-bind="attrs"
          @click="snackbar = false"
        >
          Close
        </v-btn>
      </template>
    </v-snackbar>
    <v-progress-circular
      v-if="showLoader"
      indeterminate
      :size="50"
      :width="10"
    ></v-progress-circular>
  </v-app>
</template>
<script>
import vuetifyPaginationVue from "./vuetifyPagination.vue";
import GroupRequests from "./GroupRequests.vue";
import ViewRequestDetails from "./ViewRequestDetails.vue";
import axios from "axios";
import config from "../config";
import Header from "./Header.vue";
import FileSaver from 'file-saver';

export default {
  name: "requestDetails",
  components: {
    viewRequestDetails: ViewRequestDetails,
    'navbar':Header
  },
  data: () => ({
    dialog:false,
    // termBeforeEdit:"",
    // termAfterEdit:"",
    // mileageBeforeEdit:"",
    // mileageAfterEdit:"",
    formBeforeEdit:{},
    formAfterEdit:{},
    
    comment:"",
    editable:false,
    model: null,
    snackBarText: "Saved Successfully",
    snackbar: false,
    items: ["Request Overview", "Request Details"],
    requestDetails:{
     programGuideId: "",
     stepName: "",
     assignedTo: "",
     requestor: "",
     startDate: "",
     endDate: null,
     state: "",
     modelYear: "",
     model: "",
     lookup: "",
     location: "",
     baseMSRP:"",
     p1Package: "",
     option1: "",
     option2: "",
     option3: "",
     equippedMSRP: "",
     destinationCharge: "",
     totalMSRP: "",
     dealerContribution: "",
     customerDown: "",
     federalTaxCredit: "",
     capitalizedCost: "",
     term: "",
     mileagePerYear: "",
     baseRV: "",
     rvEnhancement: "",
     publishedRV: ""
    },
    proposalId :"",
    responseBody:[],
    editable:false,
    updatedObject:{
      term:"",
      mileagePerYear:"",
      baseRV:"",
      rvEnhancement:"",
      publishedRV:""
    },
    stepper:1,
    steps: [
    {
        steps: "Process Initiated",
        skipped: false,
        completed: true,
        current: false
    },
    {
        steps: "Sales Ops",
        skipped: false,
        completed: true,
        current: false
    },
    {
        steps: "Fin Cont",
        skipped: false,
        completed: false,
        current: true
    },
    {
        steps: "Process Completed",
        skipped: false,
        completed: false,
        current: false
    }
],
  history: [
    {
        activityName: "Enter Data & Set Baseline",
        activityType: "userTask",
        userId: "sriramh",
        comment: "resubmit Comment",
        startTime: "Dec 11,2020 11:35 AM IST",
        endTime: "Dec 11,2020 12:41 PM IST"
    },
    {
        activityName: "Initiate Process",
        activityType: "startEvent",
        userId: "",
        comment: "",
        startTime: "Dec 11,2020 11:35 AM IST",
        endTime: "Dec 11,2020 11:35 AM IST"
    }
],
    submitMessage:{
      "message":""
    },
    claimMessage:{
      "message":""
    },
    acceptMessage:{
      "message":""
    },
    sendBackMessage:{
      "message":""
    },
    showApprove:"",
    loggedInUser:"",
    loggedInUserGroup:"",
    isGroupUser:"",
    claimRequest:"",
    showLoader:false,
    fileData:{}
  }),
  mounted() {
    this.showApprove = sessionStorage.getItem("showApprove");
    this.loggedInUser = sessionStorage.getItem("loggedInUser");
    this.loggedInUserGroup = sessionStorage.getItem("loggedInUserGroup");
    this.isGroupUser = sessionStorage.getItem("isGroupUser");
    this.proposalId = this.$route.params.proposalId;
    this.loadMyRequestDetails();
    this.loadSteps();
    this.loadHistory();
  },
  methods: {
    cancelReplace:function(){
      this.fileData={},
      this.dialog=false;
    },
    downloadWorkflow:function(fileName){
      axios({
                url: 'http://localhost:9090/programguide/'+this.proposalId+'/download?attachmentName='+fileName,  //.substring(0, this.scenario.file.lastIndexOf("/"))
                method: "GET",
                headers: {"Accept": "application/vnd.ms-excel"},
                responseType: "blob"
            }).then(response => {
                const fileURL = window.URL.createObjectURL(new Blob([response.data]));
                const fileLink = document.createElement("a");

                fileLink.href = fileURL;
                fileLink.setAttribute("download", fileName);
                document.body.appendChild(fileLink);

                fileLink.click();
            });
    },
    downloadFile:function(fileName){
      axios({
                url: 'http://localhost:9090/programguide/'+this.proposalId+'/download?attachmentName='+fileName,  //.substring(0, this.scenario.file.lastIndexOf("/"))
                method: "GET",
                headers: {"Accept": "application/vnd.ms-excel"},
                responseType: "blob"
            }).then(response => {
                const fileURL = window.URL.createObjectURL(new Blob([response.data]));
                const fileLink = document.createElement("a");

                fileLink.href = fileURL;
                fileLink.setAttribute("download", fileName);
                document.body.appendChild(fileLink);

                fileLink.click();
            });
      // const accessToken = sessionStorage.getItem("accessToken");
      // const headers = {
      //   USER_ID: this.loggedInUser,
      //   Authorization: "Bearer " + accessToken,
      //   // responseType:'arraybuffer'
      // };
      // // var attachmentName=fileName;
      // console.log(fileName);
      
      // axios
      //   .get(config.backend.baseUrl +"/programguide/"+this.proposalId+"/download",
      //   { params: { attachmentName: fileName } },
      //   {headers}
      //   )
      //   .then((response) => {
      //     console.log(JSON.stringify(response));
      //     // var fileURL=window.URL.createObjectURL(new Blob([response.data],{type: "application/vnd.ms-excel"}));
      //     // var fileLink=document.createElement('a');
      //     // fileLink.href=fileURL;
      //     // fileLink.setAttribute('download',fileName);
      //     // document.body.appendChild(fileLink);
      //     // fileLink.click();
      //     const url = URL.createObjectURL(new Blob([response.data], {
      //         type: 'application/vnd.ms-excel'
      //     }))
      //     const link = document.createElement('a')
      //     link.href = url
      //     link.setAttribute('download', fileName)
      //     document.body.appendChild(link)
      //     link.click()
      //   })
      //   .catch((e) => {
      //     console.error(e);
      //   })
      //   .finally(() => {
      //     this.showLoader = false;
      //   });
    },
     processFile(event){
      this.fileData=event;
      console.log(this.fileData);
      if(this.fileData && this.fileData.name!=this.requestDetails.attachmentName){
        this.dialog=true;
      }
    },
    sendBack:function(){
      this.loggedInUser = sessionStorage.getItem("loggedInUser");
      const accessToken = sessionStorage.getItem("accessToken");
      const headers = {
        USER_ID: this.loggedInUser,
        "Content-Type": "application/json",
        Authorization: "Bearer " + accessToken,
      };
      
      this.showLoader = true;
       if(this.comment){
        this.sendBackMessage.message="Comment : "+this.comment;
      } 
       if((this.formBeforeEdit.term!=this.formAfterEdit.term)||(this.formBeforeEdit.mileagePerYear!=this.formAfterEdit.mileagePerYear)
          ||(this.formBeforeEdit.baseRV!=this.formAfterEdit.baseRV) || (this.formBeforeEdit.rvEnhancement!=this.formAfterEdit.rvEnhancement)
          ||(this.formBeforeEdit.publishedRV!=this.formAfterEdit.publishedRV)){
            this.sendBackMessage.message=this.sendBackMessage.message+"\n\nUpdates :"
          }  
      if(this.formBeforeEdit.term!=this.formAfterEdit.term){
        this.sendBackMessage.message=this.sendBackMessage.message+"\nTerm value changed from "+this.formBeforeEdit.term+" to "+this.formAfterEdit.term;
      }
      if(this.formBeforeEdit.mileagePerYear!=this.formAfterEdit.mileagePerYear){
        this.sendBackMessage.message=this.sendBackMessage.message+"\nMileage Per Year value changed from "+this.formBeforeEdit.mileagePerYear+" to "+this.formAfterEdit.mileagePerYear;
      }
      if(this.formBeforeEdit.baseRV!=this.formAfterEdit.baseRV){
        this.sendBackMessage.message=this.sendBackMessage.message+"\nBasr RV value changed from "+this.formBeforeEdit.baseRV+" to "+this.formAfterEdit.baseRV;
      }
       if(this.formBeforeEdit.rvEnhancement!=this.formAfterEdit.rvEnhancement){
        this.sendBackMessage.message=this.sendBackMessage.message+"\nRV Enhancement value changed from "+this.formBeforeEdit.rvEnhancement+" to "+this.formAfterEdit.rvEnhancement;
      }
       if(this.formBeforeEdit.publishedRV!=this.formAfterEdit.publishedRV){
        this.sendBackMessage.message=this.sendBackMessage.message+"\nPublished RV value changed from "+this.formBeforeEdit.publishedRV+" to "+this.formAfterEdit.publishedRV;
      }
      axios
        .post(
          config.backend.baseUrl + "/groups/"+this.loggedInUserGroup+"/programguide/"+this.proposalId+"/sendback",
         this.sendBackMessage,
          
          { headers }
        )
        .then((response) => {
         
          if (response.status == 200) {
            console.log("Saved Successfully");
            this.snackBarText = "Sent back to SalesOps";
            this.snackbar = true;
            setTimeout(this.back, 2000);
          } else {
            this.snackBarText = "Something Went Wrong";
            this.snackbar = true;
          }

          // this.processResponseBody();
        })
        .catch((e) => {
          this.snackBarText =
            "An unexpected error has occured. Please try again later.";
          this.snackbar = true;
          console.error(e);
        })
        .finally(() => {
          this.showLoader = false;
        });
    },
    accept:function(){
      this.loggedInUser = sessionStorage.getItem("loggedInUser");
      const accessToken = sessionStorage.getItem("accessToken");
      const headers = {
        USER_ID: this.loggedInUser,
        "Content-Type": "application/json",
        Authorization: "Bearer " + accessToken,
      };
      
      this.showLoader = true;
       if(this.comment){
        this.acceptMessage.message="Comment : "+this.comment;
      } 
       if((this.formBeforeEdit.term!=this.formAfterEdit.term)||(this.formBeforeEdit.mileagePerYear!=this.formAfterEdit.mileagePerYear)
          ||(this.formBeforeEdit.baseRV!=this.formAfterEdit.baseRV) || (this.formBeforeEdit.rvEnhancement!=this.formAfterEdit.rvEnhancement)
          ||(this.formBeforeEdit.publishedRV!=this.formAfterEdit.publishedRV)){
            this.acceptMessage.message=this.acceptMessage.message+"\n\nUpdates :"
          }  
      // this.acceptMessage.message=this.acceptMessage.message+"\n\nUpdates : ";
      if(this.formBeforeEdit.term!=this.formAfterEdit.term){
        this.acceptMessage.message=this.acceptMessage.message+"\nTerm value changed from "+this.formBeforeEdit.term+" to "+this.formAfterEdit.term;
      }
      if(this.formBeforeEdit.mileagePerYear!=this.formAfterEdit.mileagePerYear){
        this.acceptMessage.message=this.acceptMessage.message+"\nMileage Per Year value changed from "+this.formBeforeEdit.mileagePerYear+" to "+this.formAfterEdit.mileagePerYear;
      }
      if(this.formBeforeEdit.baseRV!=this.formAfterEdit.baseRV){
        this.acceptMessage.message=this.acceptMessage.message+"\nBase RV value changed from "+this.formBeforeEdit.baseRV+" to "+this.formAfterEdit.baseRV;
      }
       if(this.formBeforeEdit.rvEnhancement!=this.formAfterEdit.rvEnhancement){
        this.acceptMessage.message=this.acceptMessage.message+"\nRV Enhancement value changed from "+this.formBeforeEdit.rvEnhancement+" to "+this.formAfterEdit.rvEnhancement;
      }
       if(this.formBeforeEdit.publishedRV!=this.formAfterEdit.publishedRV){
        this.acceptMessage.message=this.acceptMessage.message+"\nPublished RV value changed from "+this.formBeforeEdit.publishedRV+" to "+this.formAfterEdit.publishedRV;
      }
      axios
        .post(
          config.backend.baseUrl + "/groups/"+this.loggedInUserGroup+"/programguide/"+this.proposalId+"/approve",
         this.acceptMessage,
          
          { headers }
        )
        .then((response) => {
         
          if (response.status == 200) {
            console.log("Saved Successfully");
            this.snackBarText = "Successfully Approved";
            this.snackbar = true;
            setTimeout(this.back, 2000);
          } else {
            this.snackBarText = "Something Went Wrong";
            this.snackbar = true;
          }

          // this.processResponseBody();
        })
        .catch((e) => {
          this.snackBarText =
            "An unexpected error has occured. Please try again later.";
          this.snackbar = true;
          console.error(e);
        })
        .finally(() => {
          this.showLoader = false;
        });
    },
    claimProposal:function(){
      console.log("Claim Proposal");
      this.loggedInUser = sessionStorage.getItem("loggedInUser");
      const accessToken = sessionStorage.getItem("accessToken");
      const headers = {
        USER_ID: this.loggedInUser,
        "Content-Type": "application/json",
        Authorization: "Bearer " + accessToken,
      };
      
      this.showLoader = true;
      
      axios
        .post(
          config.backend.baseUrl + "/groups/"+this.loggedInUserGroup+"/programguide/"+this.proposalId+"/claim",
         this.claimMessage,
          
          { headers }
        )
        .then((response) => {
         
          if (response.status == 200) {
            console.log("Saved Successfully");
            this.snackBarText = "Claimed Successfully";
            this.snackbar = true;
            setTimeout(this.back, 2000);
          } else {
            this.snackBarText = "Something Went Wrong";
            this.snackbar = true;
          }

          // this.processResponseBody();
        })
        .catch((e) => {
          this.snackBarText =
            "An unexpected error has occured. Please try again later.";
          this.snackbar = true;
          console.error(e);
        })
        .finally(() => {
          this.showLoader = false;
        });
    },
    loadHistory:function(){
      console.log("loadHistory")
      const accessToken = sessionStorage.getItem("accessToken");
      const headers = {
        USER_ID: this.loggedInUser,
        "Content-Type": "application/json",
        Authorization: "Bearer " + accessToken,
      };
      // this.showLoader = true;
      axios
        .get(config.backend.baseUrl +"/programguide/"+this.proposalId+"/history?sortBy=startTime&sortOrder=desc&firstResult=0&maxResults=100", {
          headers,
        })
        .then((response) => {
          this.history = response.data;
          // console.log(JSON.stringify(this.history))
        })
        .catch((e) => {
          console.error(e);
        })
        .finally(() => {
          this.showLoader = false;
        });
    },
    loadSteps:function(){
      console.log("loadsteps")
      const accessToken = sessionStorage.getItem("accessToken");
      const headers = {
        USER_ID: this.loggedInUser,
        "Content-Type": "application/json",
        Authorization: "Bearer " + accessToken,
      };
      this.showLoader = true;
      axios
        .get(config.backend.baseUrl + "/programguide/"+this.proposalId+"/steps", {
          headers,
        })
        .then((response) => {
          this.steps = response.data;
          // console.log(JSON.stringify(this.steps))
        })
        .catch((e) => {
          console.error(e);
        })
        .finally(() => {
          this.showLoader = false;
        });
    },
    submit:function(){
      this.loggedInUser = sessionStorage.getItem("loggedInUser");
      const accessToken = sessionStorage.getItem("accessToken");
      const headers = {
        USER_ID: this.loggedInUser,
        "Content-Type": "application/json",
        Authorization: "Bearer " + accessToken,
      };

      // console.log("send for review",this.formBeforeEdit,this.formAfterEdit);
      console.log("comment Object::",this.formBeforeEdit,this.formAfterEdit);
      
      this.showLoader = true;
      // this.submitMessage;
      if(this.comment){
        this.submitMessage.message="Comment : "+this.comment;
      } 
      if((this.formBeforeEdit.term!=this.formAfterEdit.term)||(this.formBeforeEdit.mileagePerYear!=this.formAfterEdit.mileagePerYear)
          ||(this.formBeforeEdit.baseRV!=this.formAfterEdit.baseRV) || (this.formBeforeEdit.rvEnhancement!=this.formAfterEdit.rvEnhancement)
          ||(this.formBeforeEdit.publishedRV!=this.formAfterEdit.publishedRV)){
            this.submitMessage.message=this.submitMessage.message+"\n\nUpdates :"
          }   
      
      if(this.formBeforeEdit.term!=this.formAfterEdit.term){
        
        this.submitMessage.message=this.submitMessage.message+"\nTerm value changed from "+this.formBeforeEdit.term+" to "+this.formAfterEdit.term;
      }
      if(this.formBeforeEdit.mileagePerYear!=this.formAfterEdit.mileagePerYear){
        this.submitMessage.message=this.submitMessage.message+"\nMileage Per Year value changed from "+this.formBeforeEdit.mileagePerYear+" to "+this.formAfterEdit.mileagePerYear;
      }
      if(this.formBeforeEdit.baseRV!=this.formAfterEdit.baseRV){
        this.submitMessage.message=this.submitMessage.message+"\nBase RV value changed from "+this.formBeforeEdit.baseRV+" to "+this.formAfterEdit.baseRV;
      }
       if(this.formBeforeEdit.rvEnhancement!=this.formAfterEdit.rvEnhancement){
        this.submitMessage.message=this.submitMessage.message+"\nRV Enhancement value changed from "+this.formBeforeEdit.rvEnhancement+" to "+this.formAfterEdit.rvEnhancement;
      }
       if(this.formBeforeEdit.publishedRV!=this.formAfterEdit.publishedRV){
        this.submitMessage.message=this.submitMessage.message+"\nPublished RV value changed from "+this.formBeforeEdit.publishedRV+" to "+this.formAfterEdit.publishedRV;
      }
      //  if(this.formBeforeEdit.attachmentName!=this.formAfterEdit.attachmentName){
      //   this.submitMessage.message=this.submitMessage.message+";Published RV value modified from "+this.formBeforeEdit.attachmentName+" to "+this.formAfterEdit.attachmentName;
      // }
      // console.log("comment::",this.submitMessage);
      axios
        .post(
          config.backend.baseUrl + "/groups/"+this.loggedInUserGroup+"/programguide/"+this.requestDetails.programGuideId+"/send",
          this.submitMessage
          ,
          { headers }
        )
        .then((response) => {
         
          if (response.status == 200) {
            console.log("Saved Successfully");
            this.snackBarText = "Sent for review";
            this.snackbar = true;
            setTimeout(this.back, 2000);
          } else {
            this.snackBarText = "Something Went Wrong";
            this.snackbar = true;
          }
        })
        .catch((e) => {
          this.snackBarText =
            "An unexpected error has occured. Please try again later.";
          this.snackbar = true;
          console.error(e);
        })
        .finally(() => {
          this.showLoader = false;
        });
    },
    close:function(){
      this.fileData={};
      this.editable=false;
    },
    updateRequest:function(){
    // console.log(JSON.stringify(this.requestDetails));
    this.formAfterEdit=this.requestDetails;
    // console.log(this.formBeforeEdit,this.formAfterEdit);
    this.loggedInUser = sessionStorage.getItem("loggedInUser");
      const accessToken = sessionStorage.getItem("accessToken");
      const headers = {
        USER_ID: this.loggedInUser,
        "Content-Type": "multipart/form-data",
        Authorization: "Bearer " + accessToken,
      };
      
      this.showLoader = true;
     var formData=new FormData();
      // formData.append('request',this.requestBody);
      formData.append('request', new Blob([JSON.stringify(this.requestDetails)], { type: 'application/json'}));
      // formData.append('request', JSON.stringify(this.requestBody), { type: 'application/json'});
      formData.append('file',this.fileData);
      // console.log(JSON.stringify(formData));
      axios
        .put(
          config.backend.baseUrl + "/programguide/"+this.requestDetails.programGuideId,

          formData,
          { headers }
        )
        .then((response) => {

          if (response.status == 200) {
            console.log("Saved Successfully");
            this.snackBarText = this.proposalId+" Updated";
            this.snackbar = true;
            this.editable=false;
            // setTimeout(this.back, 2000);
          } else {
            this.snackBarText = "Something Went Wrong";
            this.snackbar = true;
          }

        })
        .catch((e) => {
          this.snackBarText =
            "An unexpected error has occured. Please try again later.";
          this.snackbar = true;
          console.error(e);
        })
        .finally(() => {
          this.showLoader = false;
        });
    },
    makeEditable:function(){
      // this.termBeforeEdit=this.requestDetails.term;
      this.formBeforeEdit.term=this.requestDetails.term;
      this.formBeforeEdit.mileagePerYear=this.requestDetails.mileagePerYear;
      this.formBeforeEdit.baseRV=this.requestDetails.baseRV;
      this.formBeforeEdit.rvEnhancement=this.requestDetails.rvEnhancement;
      this.formBeforeEdit.publishedRV=this.requestDetails.publishedRV;
      this.editable=true;
    },
    
  back: function (event) {
    console.log("back")
      this.$router.go(-1);
    },
    loadMyRequestDetails: function () {
      const accessToken = sessionStorage.getItem("accessToken");
      const headers = {
        USER_ID: this.loggedInUser,
        "Content-Type": "application/json",
        Authorization: "Bearer " + accessToken,
      };
      // this.showLoader = true;
      axios
        .get(config.backend.baseUrl + "/programguide/" + this.proposalId, {
          headers,
        })
        .then((response) => {
          this.responseBody = response.data;
          this.requestDetails=this.responseBody;
          
          // console.log(JSON.stringify(this.responseBody))
          // this.processResponseBody();
        })
        .catch((e) => {
          console.error(e);
        })
        .finally(() => {
          // this.showLoader = false;
        });
    }
  },
};
</script>

<style scoped>
.text-left{
  font:13px osb, Helvetica, sans-serif;
}

.subHeader-heading{
  font:1.5em osb, Helvetica, sans-serif;   
  text-transform: uppercase;
}

.commentTextArea.v-text-field {
  padding-top: 0px;
  border: 0px;
}

.scroll {
  overflow-y: scroll;
}

.v-stepper {
  font: 14px osl, Hevetica, sans-serif;
}

.v-stepper__step {
  padding: 18px;
}

.tab-buttons :active{
   background-color: #4cc0c1 !important;
   color: white;
}

.v-tabs{
  margin-bottom: 4px;
}

.v-tab{
  background-color: black !important;
  border-color: black !important;
  color: white !important;
  border: solid 5px;
  box-shadow: none !important;
  font-family: 'Open Sans', sans-serif;
  font-size: 12px;
  font-weight: 600;
  touch-action: manipulation;
  border: 1px solid transparent;
  white-space: nowrap;
  margin-top: 10px;
  margin-right: 5px;
  border-top-left-radius: 7px;
  border-top-right-radius: 7px;
}

.v-tab--active{
  background-color: #4cc0c1  !important;
  border-color: #4cc0c1  !important;
}

.request-card{
  font:13px osb, Helvetica, sans-serif;
  height: 300px;
}

tr{
  font:13px osb, Helvetica, sans-serif;
  height: 20px;
}

.v-timeline{
  font:13px osb, Helvetica, sans-serif;
}

h2{
  font:17px osb, Helvetica, sans-serif;   
  text-transform: uppercase;
  font-weight: bold;
}

.back-btn-wrapper {
  padding-top: 1%;
}

.save-btn-wrapper {
  text-align: right;
}

.edit-button{
  position: absolute;
  right: 0;
  margin-right: 10px;
}

.update-button{
  /* position: absolute;
  right: 0; */
  margin-right: 10px;
  margin-bottom: 20px;
  margin-top: 20px;
}

.submit-button{
  position:absolute;
  right: 0;
  margin-right: 10px;
}

.comment-div{
  margin-left: 20px;
  margin-right: 20px;
}

.dialog-text{
  font-size: 13px;
  font-family: Arial, Helvetica, sans-serif;
  margin-left: 70px ;
  margin-top: 20px;
}
.dialog-button{
  margin-left: 150px;
}
.v-dialog--active{
  background-color: white;
}
.comment{
  font:'13px osb, Helvetica, sans-serif';
}
</style>